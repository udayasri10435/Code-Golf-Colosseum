import React, { useState, useEffect } from 'react';
import { Challenge, LanguageBracket, ExecutionReport } from '../types/golf';
import { CHALLENGES } from '../data/challenges';
import { executeGolfCode } from '../utils/golfRunner';
import { Swords, Trophy, Play, RotateCcw, CheckCircle, Flame, ShieldAlert, Award } from 'lucide-react';

interface BotRival {
  id: string;
  name: string;
  title: string;
  avatarSeed: string;
  difficulty: 'Novice' | 'Veteran' | 'Grandmaster';
  solutions: Record<string, string>; // challengeId -> code
}

const BOT_RIVALS: BotRival[] = [
  {
    id: 'bot-novice',
    name: 'Gladiator Neophyte',
    title: 'Verbose Automaton',
    avatarSeed: 'bot-1',
    difficulty: 'Novice',
    solutions: {
      fizzbuzz: 'n=>Array.from({length:n},(_,i)=>((i+1)%15==0?"FizzBuzz":(i+1)%3==0?"Fizz":(i+1)%5==0?"Buzz":i+1))',
      isprime: 'n=>{if(n<=1)return false;for(let i=2;i*i<=n;i++)if(n%i==0)return false;return true}',
      palindrome_perm: 's=>{const m={};for(let c of s)m[c]=(m[c]||0)+1;return Object.values(m).filter(x=>x%2).length<=1}',
      rle: 's=>{let o="",c=1;for(let i=0;i<s.length;i++){if(s[i]==s[i+1])c++;else{o+=s[i]+c;c=1}}return o}'
    }
  },
  {
    id: 'bot-slayer',
    name: 'ByteSlayer_99',
    title: 'Colosseum Centurion',
    avatarSeed: 'bot-2',
    difficulty: 'Veteran',
    solutions: {
      fizzbuzz: 'n=>[...Array(n)].map((_,i)=>(++i%3?"":"Fizz")+(i%5?"":"Buzz")||i)',
      isprime: 'p=(n,i=2)=>i*i>n||(n%i&&p(n,i+1))',
      palindrome_perm: 's=>new Set([...s].filter(c=>[...s].filter(x=>x==c).length%2)).size<2',
      rle: 's=>s.replace(/(.)\\1*/g,m=>m[0]+m.length)'
    }
  },
  {
    id: 'bot-deity',
    name: 'RegexDemon',
    title: 'The One-Liner Deity',
    avatarSeed: 'bot-3',
    difficulty: 'Grandmaster',
    solutions: {
      fizzbuzz: 'n=>[...Array(n)].map((_,i)=>(++i%3?"":"Fizz")+(i%5?"":"Buzz")||i)',
      isprime: 'n=>!/^1?$|^(11+?)\\1+$/.test("1".repeat(n))',
      palindrome_perm: 's=>new Set([...s].filter(c=>[...s].filter(x=>x==c).length%2)).size<2',
      rle: 's=>s.replace(/(.)\\1*/g,m=>m[0]+m.length)'
    }
  }
];

export const DuelColosseum: React.FC = () => {
  const [selectedChallenge, setSelectedChallenge] = useState<Challenge>(CHALLENGES[0]);
  const [selectedBot, setSelectedBot] = useState<BotRival>(BOT_RIVALS[1]);
  const [playerCode, setPlayerCode] = useState<string>(CHALLENGES[0].starterCode['javascript'] || '');
  const [isDueling, setIsDueling] = useState(false);
  const [playerReport, setPlayerReport] = useState<ExecutionReport | null>(null);
  const [botReport, setBotReport] = useState<ExecutionReport | null>(null);
  const [duelWinner, setDuelWinner] = useState<'player' | 'bot' | 'draw' | null>(null);

  // Synchronize when challenge or bot changes
  useEffect(() => {
    setPlayerCode(selectedChallenge.starterCode['javascript'] || '');
    setPlayerReport(null);
    setBotReport(null);
    setDuelWinner(null);
  }, [selectedChallenge.id, selectedBot.id]);

  const botCode = selectedBot.solutions[selectedChallenge.id] || selectedChallenge.standardVerboseCode['javascript'];
  const playerBytes = new TextEncoder().encode(playerCode).length;
  const botBytes = new TextEncoder().encode(botCode).length;
  const delta = playerBytes - botBytes;

  const handleExecuteDuel = async () => {
    setIsDueling(true);
    setDuelWinner(null);

    const allTests = [...selectedChallenge.visibleTests, ...selectedChallenge.hiddenTests];

    try {
      const pReport = await executeGolfCode(playerCode, 'javascript', allTests, selectedChallenge.functionName);
      const bReport = await executeGolfCode(botCode, 'javascript', allTests, selectedChallenge.functionName);

      setPlayerReport(pReport);
      setBotReport(bReport);

      if (pReport.allPassed && !bReport.allPassed) {
        setDuelWinner('player');
      } else if (!pReport.allPassed && bReport.allPassed) {
        setDuelWinner('bot');
      } else if (pReport.allPassed && bReport.allPassed) {
        if (pReport.byteCount < bReport.byteCount) {
          setDuelWinner('player');
        } else if (pReport.byteCount > bReport.byteCount) {
          setDuelWinner('bot');
        } else {
          setDuelWinner('draw');
        }
      } else {
        setDuelWinner(null);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsDueling(false);
    }
  };

  return (
    <div className="p-6 max-w-[1560px] mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-neutral-100 flex items-center gap-2">
            <Swords className="w-5 h-5 text-amber-500" />
            <span>Colosseum Head-to-Head Duel Arena</span>
          </h1>
          <p className="text-xs text-neutral-400 mt-0.5">
            Real-time split bout against Colosseum Champions. Fewer bytes while passing all tests takes the laurel crown.
          </p>
        </div>

        {/* Rival selector */}
        <div className="flex items-center gap-3">
          <span className="text-xs text-neutral-400 font-medium">Opponent:</span>
          <div className="flex items-center gap-1.5 bg-neutral-900 border border-neutral-800 rounded-lg p-1">
            {BOT_RIVALS.map(bot => (
              <button
                key={bot.id}
                onClick={() => setSelectedBot(bot)}
                className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                  selectedBot.id === bot.id
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                {bot.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Duel Control & Challenge Switcher */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 rounded-xl p-4">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <span className="text-xs text-neutral-400 shrink-0">Challenge Arena:</span>
          <select
            value={selectedChallenge.id}
            onChange={e => {
              const c = CHALLENGES.find(x => x.id === e.target.value);
              if (c) setSelectedChallenge(c);
            }}
            className="bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-1.5 text-xs font-semibold text-neutral-200 focus:outline-none cursor-pointer w-full sm:w-64"
          >
            {CHALLENGES.map(c => (
              <option key={c.id} value={c.id}>
                {c.title}
              </option>
            ))}
          </select>
        </div>

        {/* Live Delta Gauge */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="text-right">
            <span className="text-neutral-400 text-[11px] block">Byte Delta</span>
            <span
              className={`font-bold tabular-nums text-sm ${
                delta < 0
                  ? 'text-emerald-400'
                  : delta > 0
                  ? 'text-rose-400'
                  : 'text-neutral-300'
              }`}
            >
              {delta < 0
                ? `${Math.abs(delta)}B Ahead (Lead)`
                : delta > 0
                ? `+${delta}B Behind`
                : 'Tied 0B'}
            </span>
          </div>

          <button
            onClick={handleExecuteDuel}
            disabled={isDueling}
            className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-neutral-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 rounded-lg transition-colors shadow-sm ml-2"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isDueling ? 'Dueling in Sandboxes...' : 'Fight Duel!'}</span>
          </button>
        </div>
      </div>

      {/* Duel Victory Banner */}
      {duelWinner && (
        <div
          className={`p-4 rounded-xl border flex items-center justify-between transition-all ${
            duelWinner === 'player'
              ? 'bg-emerald-950/40 border-emerald-500/60 text-emerald-200'
              : duelWinner === 'bot'
              ? 'bg-rose-950/40 border-rose-500/60 text-rose-200'
              : 'bg-neutral-900 border-neutral-700 text-neutral-200'
          }`}
        >
          <div className="flex items-center gap-3">
            <Award className="w-6 h-6 text-amber-400 shrink-0" />
            <div>
              <h3 className="text-sm font-bold">
                {duelWinner === 'player'
                  ? 'VICTORY IN THE COLOSSEUM! You out-golfed the Champion!'
                  : duelWinner === 'bot'
                  ? `${selectedBot.name} claims the laurel with fewer bytes!`
                  : 'Dead Heat! Equal byte weights!'}
              </h3>
              <p className="text-xs opacity-80 font-mono">
                {duelWinner === 'player'
                  ? `Your score: ${playerBytes} Bytes vs Opponent: ${botBytes} Bytes (Saved ${botBytes - playerBytes} Bytes)`
                  : `Opponent: ${botBytes} Bytes vs You: ${playerBytes} Bytes`}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Split Duel Arena */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left: Player Arena */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden flex flex-col shadow-sm">
          <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-800 bg-neutral-950/80">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/50" />
              <span className="text-xs font-bold text-neutral-100">You (Gladiator Challenger)</span>
            </div>
            <div className="font-mono text-xs text-neutral-300">
              <span className="font-bold text-amber-300 tabular-nums">{playerBytes}</span> Bytes
            </div>
          </div>

          <div className="p-3 bg-neutral-950 flex-1 font-mono text-xs">
            <textarea
              value={playerCode}
              onChange={e => setPlayerCode(e.target.value)}
              spellCheck={false}
              className="w-full h-64 bg-transparent text-neutral-200 focus:outline-none resize-none font-mono leading-relaxed"
              placeholder="Golf your code here..."
            />
          </div>

          {playerReport && (
            <div className="p-3 border-t border-neutral-800 bg-neutral-950/90 text-xs font-mono flex items-center justify-between">
              <span className={playerReport.allPassed ? 'text-emerald-400' : 'text-rose-400'}>
                {playerReport.allPassed ? '✓ All Tests Passed' : `✗ Failed (${playerReport.passedTests}/${playerReport.totalTests})`}
              </span>
              <span className="text-neutral-500 tabular-nums">{playerReport.totalTimeMs}ms</span>
            </div>
          )}
        </div>

        {/* Right: Rival Bot Arena */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden flex flex-col shadow-sm">
          <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-800 bg-neutral-950/80">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-400 shadow-sm shadow-rose-400/50" />
              <span className="text-xs font-bold text-neutral-100">{selectedBot.name}</span>
              <span className="text-[10px] text-neutral-400 uppercase font-mono">({selectedBot.difficulty})</span>
            </div>
            <div className="font-mono text-xs text-neutral-300">
              <span className="font-bold text-amber-300 tabular-nums">{botBytes}</span> Bytes
            </div>
          </div>

          <div className="p-3 bg-neutral-950 flex-1 font-mono text-xs">
            <pre className="w-full h-64 overflow-y-auto text-neutral-400 whitespace-pre-wrap break-all select-none leading-relaxed">
              {botCode}
            </pre>
          </div>

          {botReport && (
            <div className="p-3 border-t border-neutral-800 bg-neutral-950/90 text-xs font-mono flex items-center justify-between">
              <span className={botReport.allPassed ? 'text-emerald-400' : 'text-rose-400'}>
                {botReport.allPassed ? '✓ All Tests Passed' : `✗ Failed (${botReport.passedTests}/${botReport.totalTests})`}
              </span>
              <span className="text-neutral-500 tabular-nums">{botReport.totalTimeMs}ms</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
