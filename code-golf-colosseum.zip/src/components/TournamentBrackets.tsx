import React, { useState } from 'react';
import { TournamentMatch, LanguageBracket } from '../types/golf';
import { INITIAL_TOURNAMENT_MATCHES } from '../data/leaderboard';
import { Trophy, Swords, Zap, CheckCircle2, Play } from 'lucide-react';

interface TournamentBracketsProps {
  onEnterMatch: (challengeTitle: string, targetBytes: number) => void;
}

export const TournamentBrackets: React.FC<TournamentBracketsProps> = ({ onEnterMatch }) => {
  const [matches, setMatches] = useState<TournamentMatch[]>(INITIAL_TOURNAMENT_MATCHES);
  const [selectedMatch, setSelectedMatch] = useState<TournamentMatch | null>(matches[3]);

  const quarters = matches.filter(m => m.round === 'Quarterfinals');
  const semis = matches.filter(m => m.round === 'Semifinals');
  const finals = matches.filter(m => m.round === 'Grand Finals');

  return (
    <div className="p-6 max-w-[1560px] mx-auto space-y-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-neutral-100 flex items-center gap-2">
            <Swords className="w-5 h-5 text-amber-500" />
            <span>Colosseum Championship Elimination Bracket</span>
          </h1>
          <p className="text-xs text-neutral-400 mt-0.5">
            Head-to-head elimination tournament where only the gladiator with the leanest byte count advances.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-neutral-400">Current Arena Season:</span>
          <span className="text-xs font-mono font-bold text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded border border-amber-400/20">
            SEASON VII: BYTE HARVEST
          </span>
        </div>
      </div>

      {/* Bracket Tree View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 relative">
        {/* Quarterfinals Column */}
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono">
              Quarterfinals (Bout 1 & 2)
            </span>
            <span className="text-[11px] text-neutral-500 font-mono">Best of 1</span>
          </div>

          <div className="space-y-4">
            {quarters.map(match => (
              <div
                key={match.id}
                onClick={() => setSelectedMatch(match)}
                className={`bg-neutral-900 border rounded-xl p-4 space-y-2.5 cursor-pointer transition-all ${
                  selectedMatch?.id === match.id
                    ? 'border-amber-500/80 shadow-md shadow-amber-500/10'
                    : 'border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center justify-between text-[11px] text-neutral-400 border-b border-neutral-800/80 pb-1.5">
                  <span className="font-semibold text-neutral-300">{match.challengeTitle}</span>
                  <span className="font-mono text-neutral-500 uppercase">{match.gladiatorA.language}</span>
                </div>

                {/* Contender A */}
                <div
                  className={`flex items-center justify-between p-2 rounded-lg text-xs font-mono ${
                    match.winnerId === match.gladiatorA.name
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold'
                      : 'bg-neutral-950 text-neutral-300'
                  }`}
                >
                  <span className="truncate">{match.gladiatorA.name}</span>
                  <span className="tabular-nums font-bold">{match.gladiatorA.bytes} B</span>
                </div>

                {/* Contender B */}
                <div
                  className={`flex items-center justify-between p-2 rounded-lg text-xs font-mono ${
                    match.winnerId === match.gladiatorB.name
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold'
                      : 'bg-neutral-950 text-neutral-300'
                  }`}
                >
                  <span className="truncate">{match.gladiatorB.name}</span>
                  <span className="tabular-nums font-bold">{match.gladiatorB.bytes} B</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Semifinals Column */}
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono">
              Semifinals (Bout 3)
            </span>
            <span className="text-[11px] text-neutral-500 font-mono">Final 4</span>
          </div>

          <div className="space-y-4">
            {semis.map(match => (
              <div
                key={match.id}
                onClick={() => setSelectedMatch(match)}
                className={`bg-neutral-900 border rounded-xl p-4 space-y-2.5 cursor-pointer transition-all ${
                  selectedMatch?.id === match.id
                    ? 'border-amber-500/80 shadow-md shadow-amber-500/10'
                    : 'border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center justify-between text-[11px] text-neutral-400 border-b border-neutral-800/80 pb-1.5">
                  <span className="font-semibold text-neutral-300">{match.challengeTitle}</span>
                  <span className="font-mono text-neutral-500 uppercase">{match.gladiatorA.language}</span>
                </div>

                <div
                  className={`flex items-center justify-between p-2 rounded-lg text-xs font-mono ${
                    match.winnerId === match.gladiatorA.name
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold'
                      : 'bg-neutral-950 text-neutral-300'
                  }`}
                >
                  <span className="truncate">{match.gladiatorA.name}</span>
                  <span className="tabular-nums font-bold">{match.gladiatorA.bytes} B</span>
                </div>

                <div
                  className={`flex items-center justify-between p-2 rounded-lg text-xs font-mono ${
                    match.winnerId === match.gladiatorB.name
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold'
                      : 'bg-neutral-950 text-neutral-300'
                  }`}
                >
                  <span className="truncate">{match.gladiatorB.name}</span>
                  <span className="tabular-nums font-bold">{match.gladiatorB.bytes} B</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Grand Finals Column */}
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400 font-mono flex items-center gap-1.5">
              <Trophy className="w-3.5 h-3.5" />
              <span>Grand Finals (Championship)</span>
            </span>
            <span className="text-[11px] text-amber-400/80 font-mono animate-pulse">LIVE NOW</span>
          </div>

          <div className="space-y-4">
            {finals.map(match => (
              <div
                key={match.id}
                onClick={() => setSelectedMatch(match)}
                className={`bg-neutral-900 border-2 rounded-xl p-5 space-y-3 cursor-pointer transition-all ${
                  selectedMatch?.id === match.id
                    ? 'border-amber-400 shadow-lg shadow-amber-500/15'
                    : 'border-amber-500/50 hover:border-amber-400'
                }`}
              >
                <div className="flex items-center justify-between text-xs text-neutral-400 border-b border-neutral-800/80 pb-2">
                  <span className="font-bold text-neutral-100">{match.challengeTitle}</span>
                  <span className="text-[10px] text-amber-400 font-mono font-semibold bg-amber-400/10 px-2 py-0.5 rounded">
                    TITLE BOUT
                  </span>
                </div>

                {/* Champion Defender */}
                <div className="flex items-center justify-between p-2.5 rounded-lg text-xs font-mono bg-neutral-950 border border-neutral-800">
                  <div className="flex items-center gap-2">
                    <span className="text-neutral-400">Reigning:</span>
                    <span className="font-bold text-amber-300">{match.gladiatorA.name}</span>
                  </div>
                  <span className="tabular-nums font-bold text-neutral-200">{match.gladiatorA.bytes} Bytes</span>
                </div>

                {/* Challenger: The User */}
                <div className="flex items-center justify-between p-2.5 rounded-lg text-xs font-mono bg-amber-500/10 border border-amber-500/40 text-amber-200">
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400">Challenger:</span>
                    <span className="font-bold text-amber-100">{match.gladiatorB.name}</span>
                  </div>
                  <span className="text-[11px] font-semibold text-amber-400">Target: &lt;58 B</span>
                </div>

                <button
                  onClick={e => {
                    e.stopPropagation();
                    onEnterMatch(match.challengeTitle, match.gladiatorA.bytes);
                  }}
                  className="w-full mt-2 py-2 text-xs font-semibold text-neutral-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <Swords className="w-3.5 h-3.5" />
                  <span>Enter Finals in Arena</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
