import React, { useState } from 'react';
import { GOLF_TRICKS } from '../data/tricks';
import { LanguageBracket, GolfTrick } from '../types/golf';
import { BookOpen, Search, X, Check, Copy } from 'lucide-react';

interface GolfGrimoireModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyTrick?: (trick: GolfTrick) => void;
}

export const GolfGrimoireModal: React.FC<GolfGrimoireModalProps> = ({ isOpen, onClose }) => {
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageBracket | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredTricks = GOLF_TRICKS.filter(trick => {
    const matchesLang = selectedLanguage === 'all' || trick.language === selectedLanguage;
    const query = searchQuery.toLowerCase();
    const matchesSearch =
      trick.title.toLowerCase().includes(query) ||
      trick.explanation.toLowerCase().includes(query) ||
      trick.before.toLowerCase().includes(query) ||
      trick.after.toLowerCase().includes(query);
    return matchesLang && matchesSearch;
  });

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/60">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-500" />
            <div>
              <h2 className="text-base font-bold text-neutral-100">Grimoire of Byte Golf Tricks</h2>
              <p className="text-xs text-neutral-400">Mastery catalog of concise idioms, bitwise hacks, and language quirks</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-neutral-100 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filters & Search */}
        <div className="p-4 border-b border-neutral-800 bg-neutral-900/50 flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search golf tricks, operators..."
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-neutral-200 placeholder:text-neutral-500 focus:border-amber-500/50 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1.5 self-start sm:self-auto overflow-x-auto w-full sm:w-auto">
            {(['all', 'javascript', 'python', 'brainfuck'] as const).map(lang => (
              <button
                key={lang}
                onClick={() => setSelectedLanguage(lang)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                  selectedLanguage === lang
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 border border-transparent'
                }`}
              >
                {lang === 'all' ? 'All Languages' : lang.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        {/* Tricks List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filteredTricks.length === 0 ? (
            <div className="text-center py-12 text-neutral-500 text-xs">
              No golf tricks found matching "{searchQuery}".
            </div>
          ) : (
            filteredTricks.map((trick, idx) => {
              const trickKey = `${trick.language}-${idx}`;
              const isCopied = copiedId === trickKey;

              return (
                <div
                  key={trickKey}
                  className="bg-neutral-950/70 border border-neutral-800/80 rounded-lg p-4 space-y-2.5 transition-colors hover:border-neutral-700"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-neutral-100">{trick.title}</span>
                      <span className="text-[11px] text-amber-400/90 font-mono">({trick.bytesSaved})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-neutral-500 uppercase tracking-wide font-mono">
                        {trick.language} · {trick.category}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-neutral-400 leading-relaxed">{trick.explanation}</p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono pt-1">
                    <div className="bg-neutral-900 border border-neutral-800 rounded p-2.5">
                      <div className="text-[10px] text-rose-400 mb-1 font-sans font-semibold">Standard Verbose</div>
                      <code className="text-neutral-300 break-all">{trick.before}</code>
                    </div>

                    <div className="bg-neutral-900 border border-amber-500/30 rounded p-2.5 relative group">
                      <div className="text-[10px] text-emerald-400 mb-1 font-sans font-semibold flex items-center justify-between">
                        <span>Golfed Equivalent</span>
                        <button
                          onClick={() => handleCopy(trick.after, trickKey)}
                          className="text-neutral-400 hover:text-amber-400 p-0.5"
                          title="Copy golfed snippet"
                        >
                          {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      <code className="text-amber-300 font-semibold break-all">{trick.after}</code>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-neutral-800 bg-neutral-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-neutral-200 bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors"
          >
            Close Grimoire
          </button>
        </div>
      </div>
    </div>
  );
};
