import React, { useState } from 'react';
import { LeaderboardEntry, LanguageBracket } from '../types/golf';
import { CHALLENGES } from '../data/challenges';
import {
  Trophy,
  Medal,
  Code2,
  ExternalLink,
  ChevronDown,
  ThumbsUp,
  Search,
  Filter,
  Check,
  Copy,
  Terminal,
  Clock,
  Sparkles
} from 'lucide-react';

interface LeaderboardViewProps {
  entries: LeaderboardEntry[];
  onLoadCodeIntoArena: (challengeId: string, language: LanguageBracket, code: string) => void;
  onUpvoteEntry: (entryId: string) => void;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  entries,
  onLoadCodeIntoArena,
  onUpvoteEntry
}) => {
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageBracket | 'all'>('all');
  const [selectedChallengeId, setSelectedChallengeId] = useState<string>('all');
  const [inspectEntry, setInspectEntry] = useState<LeaderboardEntry | null>(null);
  const [copied, setCopied] = useState(false);

  // Filter entries
  const filtered = entries.filter(item => {
    const langMatch = selectedLanguage === 'all' || item.language === selectedLanguage;
    const challengeMatch = selectedChallengeId === 'all' || item.challengeId === selectedChallengeId;
    return langMatch && challengeMatch;
  });

  // Sort strictly by byte count ascending (lowest bytes = rank 1), then execution time
  const sorted = [...filtered].sort((a, b) => {
    if (a.bytes !== b.bytes) return a.bytes - b.bytes;
    return a.executionTimeMs - b.executionTimeMs;
  });

  const topThree = sorted.slice(0, 3);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const currentChallengeObj = CHALLENGES.find(c => c.id === selectedChallengeId);

  return (
    <div className="p-6 max-w-[1560px] mx-auto space-y-6">
      {/* Header & Metric Context */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-neutral-100 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <span>Colosseum Live Leaderboard & Language Brackets</span>
          </h1>
          <p className="text-xs text-neutral-400 mt-0.5">
            Ranked strictly by UTF-8 byte minimization. Fewer bytes equals higher Colosseum glory.
          </p>
        </div>

        {/* Global Stats Counter */}
        <div className="flex items-center gap-4 text-xs font-mono text-neutral-400 bg-neutral-900 border border-neutral-800 rounded-lg px-3.5 py-1.5">
          <div>
            <span className="text-neutral-500">Total Submissions:</span>{' '}
            <span className="font-semibold text-neutral-200 tabular-nums">{entries.length}</span>
          </div>
          <span className="text-neutral-700">|</span>
          <div>
            <span className="text-neutral-500">Record Low:</span>{' '}
            <span className="font-semibold text-amber-400 tabular-nums">
              {Math.min(...entries.map(e => e.bytes))} Bytes
            </span>
          </div>
        </div>
      </div>

      {/* Language Bracket Filter Bar & Challenge Selector */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 rounded-xl p-4">
        {/* Language Bracket Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full lg:w-auto pb-1 lg:pb-0">
          <span className="text-xs text-neutral-400 mr-1 shrink-0 font-medium">Bracket:</span>
          {(['all', 'javascript', 'python', 'brainfuck'] as const).map(bracket => (
            <button
              key={bracket}
              onClick={() => setSelectedLanguage(bracket)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg uppercase transition-colors whitespace-nowrap ${
                selectedLanguage === bracket
                  ? 'bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 border border-transparent'
              }`}
            >
              {bracket === 'all' ? 'All Brackets' : bracket}
            </button>
          ))}
        </div>

        {/* Challenge Filter Dropdown */}
        <div className="flex items-center gap-2 w-full lg:w-auto">
          <Filter className="w-4 h-4 text-neutral-500 shrink-0" />
          <select
            value={selectedChallengeId}
            onChange={e => setSelectedChallengeId(e.target.value)}
            className="w-full lg:w-72 bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-1.5 text-xs font-medium text-neutral-200 focus:border-amber-500/60 focus:outline-none cursor-pointer"
          >
            <option value="all">All Challenges (Global Hall of Fame)</option>
            {CHALLENGES.map(c => (
              <option key={c.id} value={c.id}>
                {c.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Top 3 Podium of Gladiators */}
      {topThree.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {topThree.map((item, idx) => {
            const isFirst = idx === 0;
            const isSecond = idx === 1;
            const medalColor = isFirst
              ? 'text-amber-400 border-amber-500/40 bg-amber-500/5'
              : isSecond
              ? 'text-slate-300 border-slate-400/30 bg-slate-400/5'
              : 'text-amber-700 border-amber-700/30 bg-amber-700/5';

            const challenge = CHALLENGES.find(c => c.id === item.challengeId);

            return (
              <div
                key={item.id}
                className={`border rounded-xl p-4 flex flex-col justify-between space-y-3 transition-colors ${medalColor}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-base font-black font-mono">#{idx + 1}</span>
                    <span className="text-xs font-semibold text-neutral-100">{item.gladiatorName}</span>
                    {item.isUser && (
                      <span className="text-[10px] text-amber-400 bg-amber-400/10 px-1.5 py-0.2 rounded border border-amber-400/30">
                        YOU
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] uppercase font-mono text-neutral-400 px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800">
                    {item.language}
                  </span>
                </div>

                <div className="flex items-baseline justify-between border-y border-neutral-800/60 py-2">
                  <span className="text-xs text-neutral-400 font-sans">Golf Score:</span>
                  <div className="text-right">
                    <span className="text-xl font-bold font-mono text-amber-300 tabular-nums">
                      {item.bytes}
                    </span>
                    <span className="text-xs text-neutral-400 ml-1 font-mono">Bytes</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="truncate max-w-[140px] text-[11px] text-neutral-400">
                    {challenge?.title || item.challengeId}
                  </span>
                  <button
                    onClick={() => setInspectEntry(item)}
                    className="text-amber-400 hover:text-amber-300 font-mono text-[11px] flex items-center gap-1"
                  >
                    <span>Inspect</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Main Leaderboard Table */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead>
              <tr className="border-b border-neutral-800 bg-neutral-950/70 text-neutral-400 font-medium">
                <th className="py-3 px-4 w-16 text-center font-mono">Rank</th>
                <th className="py-3 px-4">Gladiator</th>
                <th className="py-3 px-4">Challenge</th>
                <th className="py-3 px-4">Bracket</th>
                <th className="py-3 px-4 text-right font-mono">Bytes (UTF-8)</th>
                <th className="py-3 px-4 text-right font-mono">Chars</th>
                <th className="py-3 px-4 text-right font-mono">Speed</th>
                <th className="py-3 px-4 text-right">Age</th>
                <th className="py-3 px-4 text-center">Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {sorted.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-neutral-500">
                    No golf records recorded in this language bracket yet. Submit the first one!
                  </td>
                </tr>
              ) : (
                sorted.map((item, index) => {
                  const challenge = CHALLENGES.find(c => c.id === item.challengeId);
                  const isTop = index < 3;

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-neutral-800/40 transition-colors ${
                        item.isUser ? 'bg-amber-500/5' : ''
                      }`}
                    >
                      <td className="py-3 px-4 text-center font-mono font-bold">
                        <span
                          className={`tabular-nums ${
                            index === 0
                              ? 'text-amber-400'
                              : index === 1
                              ? 'text-slate-300'
                              : index === 2
                              ? 'text-amber-600'
                              : 'text-neutral-500'
                          }`}
                        >
                          #{index + 1}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-neutral-200">{item.gladiatorName}</span>
                          {item.isUser && (
                            <span className="text-[10px] text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/30">
                              YOU
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-neutral-300 font-medium">
                        {challenge?.title || item.challengeId}
                      </td>

                      <td className="py-3 px-4 font-mono uppercase text-neutral-400 text-[11px]">
                        {item.language}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold text-amber-300 tabular-nums">
                        {item.bytes} B
                      </td>

                      <td className="py-3 px-4 text-right font-mono text-neutral-400 tabular-nums">
                        {item.charCount}
                      </td>

                      <td className="py-3 px-4 text-right font-mono text-neutral-400 tabular-nums">
                        {item.executionTimeMs}ms
                      </td>

                      <td className="py-3 px-4 text-right text-neutral-500 text-[11px]">
                        {item.submittedAt}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => setInspectEntry(item)}
                          className="px-2.5 py-1 text-[11px] font-mono rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-amber-300 transition-colors"
                        >
                          View Code
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Code Inspection Modal */}
      {inspectEntry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col">
            <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-800 bg-neutral-950">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-neutral-100">
                    {inspectEntry.gladiatorName}'s Solution
                  </h3>
                  <span className="text-xs uppercase font-mono text-amber-400">
                    [{inspectEntry.language}]
                  </span>
                </div>
                <div className="text-xs text-neutral-400 font-mono">
                  Score: <span className="text-amber-400 font-bold">{inspectEntry.bytes} Bytes</span> · {inspectEntry.charCount} Chars
                </div>
              </div>
              <button
                onClick={() => setInspectEntry(null)}
                className="text-neutral-400 hover:text-neutral-100 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            <div className="p-4 bg-neutral-950 font-mono text-xs overflow-x-auto max-h-[340px]">
              <pre className="text-amber-300 leading-relaxed break-all whitespace-pre-wrap">
                {inspectEntry.code}
              </pre>
            </div>

            <div className="flex items-center justify-between px-5 py-3 border-t border-neutral-800 bg-neutral-950">
              <button
                onClick={() => handleCopyCode(inspectEntry.code)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:text-neutral-100 bg-neutral-800 rounded-lg transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Code'}</span>
              </button>

              <button
                onClick={() => {
                  onLoadCodeIntoArena(inspectEntry.challengeId, inspectEntry.language, inspectEntry.code);
                  setInspectEntry(null);
                }}
                className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-neutral-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors"
              >
                <span>Load into Arena Editor</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
