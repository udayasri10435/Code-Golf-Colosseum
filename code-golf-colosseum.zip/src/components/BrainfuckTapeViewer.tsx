import React, { useState } from 'react';
import { runBrainfuck } from '../utils/golfRunner';

interface BrainfuckTapeViewerProps {
  code: string;
  sampleInput: string;
}

export const BrainfuckTapeViewer: React.FC<BrainfuckTapeViewerProps> = ({ code, sampleInput }) => {
  const [inputVal, setInputVal] = useState(sampleInput || 'GOLF');
  const [displayHex, setDisplayHex] = useState(false);

  const state = React.useMemo(() => {
    return runBrainfuck(code, inputVal, 80000);
  }, [code, inputVal]);

  // Display a window of 16 cells around the pointer
  const startIdx = Math.max(0, state.pointer - 6);
  const endIdx = Math.min(30000, startIdx + 14);
  const windowCells = Array.from(state.tape.slice(startIdx, endIdx));

  return (
    <div className="border border-neutral-800 bg-neutral-900/80 rounded-lg p-3 text-xs space-y-3 font-mono">
      <div className="flex items-center justify-between text-neutral-400">
        <span className="font-semibold text-neutral-200">Brainfuck Memory Tape (30,000 Cells)</span>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-1.5 cursor-pointer text-neutral-400 hover:text-neutral-200">
            <input
              type="checkbox"
              checked={displayHex}
              onChange={e => setDisplayHex(e.target.checked)}
              className="rounded bg-neutral-950 border-neutral-700 text-amber-500 focus:ring-0"
            />
            <span>Hex values</span>
          </label>
          <span className="text-neutral-500 tabular-nums">Cycles: {state.cycles}</span>
        </div>
      </div>

      {/* Input controller */}
      <div className="flex items-center gap-2">
        <span className="text-neutral-400 shrink-0">Input Stream (,):</span>
        <input
          type="text"
          value={inputVal}
          onChange={e => setInputVal(e.target.value)}
          placeholder="Input string for ,"
          className="w-full bg-neutral-950 border border-neutral-800 rounded px-2 py-1 text-neutral-200 font-mono focus:border-amber-500/50 focus:outline-none"
        />
      </div>

      {/* Tape Cells Slider */}
      <div className="overflow-x-auto pb-1">
        <div className="flex items-center gap-1.5 min-w-max">
          {windowCells.map((val, i) => {
            const cellIndex = startIdx + i;
            const isPointer = cellIndex === state.pointer;
            const ascii = val >= 32 && val <= 126 ? String.fromCharCode(val) : '·';

            return (
              <div
                key={cellIndex}
                className={`flex flex-col items-center justify-center w-12 py-1.5 rounded border transition-colors ${
                  isPointer
                    ? 'border-amber-500 bg-amber-500/15 text-amber-300 shadow-sm shadow-amber-500/10'
                    : val > 0
                    ? 'border-neutral-700 bg-neutral-950 text-neutral-200'
                    : 'border-neutral-800/80 bg-neutral-950/60 text-neutral-500'
                }`}
              >
                <span className="text-[10px] text-neutral-500 font-mono tabular-nums">#{cellIndex}</span>
                <span className="text-sm font-semibold tabular-nums">
                  {displayHex ? `0x${val.toString(16).padStart(2, '0')}` : val}
                </span>
                <span className="text-[11px] text-neutral-400">'{ascii}'</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Output & Status */}
      <div className="flex items-center justify-between pt-1 border-t border-neutral-800/60 text-neutral-300">
        <div>
          <span className="text-neutral-500 mr-2">Output Stream (.):</span>
          <span className="font-semibold text-amber-400 bg-neutral-950 px-2 py-0.5 rounded border border-neutral-800">
            {state.output || '(empty)'}
          </span>
        </div>
        {state.aborted && (
          <span className="text-rose-400 font-medium">Loop limit reached (150k cycles)</span>
        )}
      </div>
    </div>
  );
};
