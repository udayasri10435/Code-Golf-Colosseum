import React, { useState, useEffect, useRef } from 'react';
import { Challenge, LanguageBracket, ExecutionReport, TestCase } from '../types/golf';
import { calculateGolfRating, analyzeGolfTricks, autoMinifyGolfCode } from '../utils/golfMetrics';
import { executeGolfCode } from '../utils/golfRunner';
import { BrainfuckTapeViewer } from './BrainfuckTapeViewer';
import {
  Play,
  Send,
  Zap,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  XCircle,
  HelpCircle,
  AlertTriangle,
  ChevronRight,
  Terminal,
  Cpu,
  Layers,
  Award
} from 'lucide-react';

interface ArenaEditorProps {
  challenges: Challenge[];
  activeChallenge: Challenge;
  onSelectChallenge: (challenge: Challenge) => void;
  onSubmitScore: (challengeId: string, language: LanguageBracket, code: string, bytes: number, timeMs: number) => void;
}

export const ArenaEditor: React.FC<ArenaEditorProps> = ({
  challenges,
  activeChallenge,
  onSelectChallenge,
  onSubmitScore
}) => {
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageBracket>('javascript');
  const [code, setCode] = useState<string>('');
  const [isRunning, setIsRunning] = useState(false);
  const [report, setReport] = useState<ExecutionReport | null>(null);
  const [activeTab, setActiveTab] = useState<'tests' | 'tips' | 'verbose'>('tests');
  const [minifiedNotice, setMinifiedNotice] = useState<string | null>(null);
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Synchronize starter code when challenge or language changes
  useEffect(() => {
    // If current language is not supported by challenge, pick first supported
    let lang = selectedLanguage;
    if (!activeChallenge.supportedLanguages.includes(lang)) {
      lang = activeChallenge.supportedLanguages[0];
      setSelectedLanguage(lang);
    }
    const initialCode = activeChallenge.starterCode[lang] || '';
    setCode(initialCode);
    setReport(null);
    setHasSubmitted(false);
  }, [activeChallenge.id, selectedLanguage]);

  // Compute live byte count
  const utf8Bytes = React.useMemo(() => {
    return new TextEncoder().encode(code).length;
  }, [code]);

  const charCount = code.length;

  const currentPar = activeChallenge.pars[selectedLanguage] || {
    par: 100,
    birdie: 80,
    eagle: 60,
    albatross: 50,
    holeInOne: 40
  };

  const rating = React.useMemo(() => {
    return calculateGolfRating(utf8Bytes, currentPar);
  }, [utf8Bytes, currentPar]);

  const liveSuggestions = React.useMemo(() => {
    return analyzeGolfTricks(code, selectedLanguage);
  }, [code, selectedLanguage]);

  // Handle Tab key in editor
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const newCode = code.substring(0, start) + '  ' + code.substring(end);
      setCode(newCode);
      requestAnimationFrame(() => {
        target.selectionStart = target.selectionEnd = start + 2;
      });
    } else if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      handleRunTests();
    }
  };

  const handleRunTests = async () => {
    setIsRunning(true);
    setHasSubmitted(false);
    try {
      const allTests: TestCase[] = [
        ...activeChallenge.visibleTests,
        ...activeChallenge.hiddenTests
      ];
      const result = await executeGolfCode(code, selectedLanguage, allTests, activeChallenge.functionName);
      setReport(result);
    } catch (e: any) {
      console.error(e);
    } finally {
      setIsRunning(false);
    }
  };

  const handleAutoMinify = () => {
    const beforeBytes = utf8Bytes;
    const minified = autoMinifyGolfCode(code, selectedLanguage);
    const afterBytes = new TextEncoder().encode(minified).length;
    setCode(minified);

    const saved = beforeBytes - afterBytes;
    if (saved > 0) {
      setMinifiedNotice(`Saved ${saved} bytes! (${beforeBytes}B → ${afterBytes}B)`);
    } else {
      setMinifiedNotice('Already at minimum whitespace.');
    }
    setTimeout(() => setMinifiedNotice(null), 3000);
  };

  const handleLoadVerbose = () => {
    setCode(activeChallenge.standardVerboseCode[selectedLanguage] || '');
  };

  const handleResetStarter = () => {
    setCode(activeChallenge.starterCode[selectedLanguage] || '');
    setReport(null);
  };

  const handleSubmit = () => {
    if (!report || !report.allPassed) return;
    onSubmitScore(
      activeChallenge.id,
      selectedLanguage,
      code,
      report.byteCount,
      report.totalTimeMs
    );
    setHasSubmitted(true);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 p-6 max-w-[1560px] mx-auto">
      {/* Left Column: Challenge Briefing, Par Gauge, and Test Specifications */}
      <div className="lg:col-span-5 flex flex-col gap-4">
        {/* Challenge Switcher & Header */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 space-y-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-amber-500 tracking-wider">
              {activeChallenge.category} Division
            </span>
            <div className="flex items-center gap-2">
              <span className="text-xs text-neutral-400">Difficulty:</span>
              <span className="text-xs font-semibold text-neutral-200">{activeChallenge.difficulty}</span>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-neutral-400 block">Select Coding Challenge:</label>
            <select
              value={activeChallenge.id}
              onChange={e => {
                const found = challenges.find(c => c.id === e.target.value);
                if (found) onSelectChallenge(found);
              }}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-sm font-semibold text-neutral-100 focus:border-amber-500/60 focus:outline-none cursor-pointer"
            >
              {challenges.map(c => (
                <option key={c.id} value={c.id}>
                  {c.title} ({c.difficulty} · {c.category})
                </option>
              ))}
            </select>
          </div>

          <p className="text-xs text-neutral-300 leading-relaxed font-sans">
            {activeChallenge.description}
          </p>

          {/* Par Metric Scale */}
          <div className="bg-neutral-950/80 border border-neutral-800/80 rounded-lg p-3.5 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-neutral-400 font-medium">Colosseum Par Standards</span>
              <span className="font-mono text-neutral-300 tabular-nums">
                Language: <span className="uppercase text-amber-400">{selectedLanguage}</span>
              </span>
            </div>

            <div className="grid grid-cols-5 gap-1.5 text-center text-[11px] font-mono">
              <div className="p-1.5 rounded bg-neutral-900/90 border border-neutral-800">
                <div className="text-neutral-500 text-[10px]">Hole-in-1</div>
                <div className="text-amber-400 font-bold tabular-nums">≤ {currentPar.holeInOne}B</div>
              </div>
              <div className="p-1.5 rounded bg-neutral-900/90 border border-neutral-800">
                <div className="text-neutral-500 text-[10px]">Albatross</div>
                <div className="text-emerald-400 font-bold tabular-nums">≤ {currentPar.albatross}B</div>
              </div>
              <div className="p-1.5 rounded bg-neutral-900/90 border border-neutral-800">
                <div className="text-neutral-500 text-[10px]">Eagle</div>
                <div className="text-cyan-400 font-bold tabular-nums">≤ {currentPar.eagle}B</div>
              </div>
              <div className="p-1.5 rounded bg-neutral-900/90 border border-neutral-800">
                <div className="text-neutral-500 text-[10px]">Birdie</div>
                <div className="text-blue-400 font-bold tabular-nums">≤ {currentPar.birdie}B</div>
              </div>
              <div className="p-1.5 rounded bg-neutral-900/90 border border-neutral-800">
                <div className="text-neutral-500 text-[10px]">Par Standard</div>
                <div className="text-neutral-300 font-bold tabular-nums">≤ {currentPar.par}B</div>
              </div>
            </div>
          </div>
        </div>

        {/* Challenge Tabs: Test Specs & Hints */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 space-y-3.5 shadow-sm flex-1 flex flex-col">
          <div className="flex items-center gap-2 border-b border-neutral-800 pb-2">
            <button
              onClick={() => setActiveTab('tests')}
              className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors ${
                activeTab === 'tests'
                  ? 'bg-neutral-800 text-neutral-100'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              Test Cases ({activeChallenge.visibleTests.length} Visible + {activeChallenge.hiddenTests.length} Hidden)
            </button>
            <button
              onClick={() => setActiveTab('tips')}
              className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors ${
                activeTab === 'tips'
                  ? 'bg-neutral-800 text-neutral-100'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              Golf Tips ({activeChallenge.tips.length})
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2.5 max-h-[360px] pr-1">
            {activeTab === 'tests' && (
              <>
                {activeChallenge.visibleTests.map((t, idx) => (
                  <div key={t.id} className="p-3 rounded-lg bg-neutral-950/70 border border-neutral-800/80 space-y-1.5 text-xs font-mono">
                    <div className="flex items-center justify-between text-neutral-400">
                      <span className="font-semibold text-neutral-200">{idx + 1}. {t.name}</span>
                      <span className="text-[10px] text-neutral-500 uppercase">Visible</span>
                    </div>
                    <div className="text-neutral-400">
                      <span className="text-neutral-500 mr-2">Input:</span>
                      <code className="text-neutral-300">{JSON.stringify(t.input)}</code>
                    </div>
                    <div className="text-neutral-400">
                      <span className="text-neutral-500 mr-2">Expected:</span>
                      <code className="text-amber-400 font-semibold">{JSON.stringify(t.expected)}</code>
                    </div>
                  </div>
                ))}
                <div className="p-3 rounded-lg bg-neutral-950/40 border border-neutral-800/50 flex items-center justify-between text-xs text-neutral-400">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-neutral-500" />
                    <span>{activeChallenge.hiddenTests.length} Hidden Adversarial Edge Cases</span>
                  </div>
                  <span className="text-[10px] text-neutral-500">Evaluated on test run</span>
                </div>
              </>
            )}

            {activeTab === 'tips' && (
              <div className="space-y-2">
                {activeChallenge.tips.map((tip, i) => (
                  <div key={i} className="p-3 rounded-lg bg-neutral-950/70 border border-neutral-800/80 text-xs text-neutral-300 space-y-1">
                    <div className="flex items-center gap-1.5 text-amber-400 font-semibold text-[11px]">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Golf Technique #{i + 1}</span>
                    </div>
                    <p className="font-mono text-neutral-300">{tip}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right Column: Code Golf Editor, Real-time Byte Meter, and Test Execution */}
      <div className="lg:col-span-7 flex flex-col gap-4">
        {/* Editor Container */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm flex flex-col">
          {/* Editor Top Bar: Language Tabs & Real-time Byte Meter */}
          <div className="flex flex-wrap items-center justify-between px-4 py-2.5 border-b border-neutral-800 bg-neutral-950/80 gap-3">
            {/* Language Bracket Tabs */}
            <div className="flex items-center gap-1 p-0.5 bg-neutral-900 rounded-lg border border-neutral-800">
              {activeChallenge.supportedLanguages.map(lang => (
                <button
                  key={lang}
                  onClick={() => setSelectedLanguage(lang)}
                  className={`px-3 py-1 text-xs font-medium rounded-md uppercase transition-colors ${
                    selectedLanguage === lang
                      ? 'bg-neutral-800 text-amber-400 shadow-sm'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  {lang === 'brainfuck' ? 'Brainfuck' : lang}
                </button>
              ))}
            </div>

            {/* Live Byte Meter & Par Rank */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-xs text-neutral-400 font-sans">Size:</span>
                <span className={`text-base font-bold font-mono tabular-nums ${rating.color}`}>
                  {utf8Bytes} <span className="text-xs font-normal">Bytes</span>
                </span>
                <span className="text-xs text-neutral-500 font-mono tabular-nums">
                  ({charCount} chars)
                </span>
              </div>

              {/* Golf Rating Badge */}
              <div className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border flex items-center gap-1.5 ${rating.badgeBg}`}>
                <span>{rating.strokeSymbol}</span>
                <span>{rating.tier}</span>
              </div>
            </div>
          </div>

          {/* Quick Code Actions Bar */}
          <div className="flex items-center justify-between px-4 py-1.5 bg-neutral-950/40 border-b border-neutral-800/60 text-xs text-neutral-400">
            <div className="flex items-center gap-3">
              <button
                onClick={handleAutoMinify}
                className="flex items-center gap-1 hover:text-amber-300 transition-colors"
                title="Remove unnecessary whitespace and comments to save bytes"
              >
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                <span>Auto-Minify</span>
              </button>
              <button
                onClick={handleLoadVerbose}
                className="hover:text-neutral-200 transition-colors"
                title="Load full verbose reference code"
              >
                Verbose Baseline
              </button>
              <button
                onClick={handleResetStarter}
                className="flex items-center gap-1 hover:text-neutral-200 transition-colors"
                title="Reset code to starter template"
              >
                <RotateCcw className="w-3 h-3 text-neutral-500" />
                <span>Reset</span>
              </button>
            </div>

            {minifiedNotice && (
              <span className="text-amber-400 font-mono text-[11px] animate-pulse">
                {minifiedNotice}
              </span>
            )}

            <span className="text-[11px] text-neutral-500 font-mono">
              Ctrl+Enter to Execute
            </span>
          </div>

          {/* Code Textarea with line numbers */}
          <div className="relative flex min-h-[290px] bg-neutral-950 font-mono text-xs">
            <textarea
              ref={textareaRef}
              value={code}
              onChange={e => setCode(e.target.value)}
              onKeyDown={handleKeyDown}
              spellCheck={false}
              placeholder="Write your golf solution here..."
              className="w-full h-full min-h-[290px] p-4 bg-transparent text-neutral-200 focus:outline-none resize-y font-mono leading-relaxed"
            />
          </div>

          {/* Dynamic Golf Reduction Suggestions */}
          {liveSuggestions.length > 0 && (
            <div className="px-4 py-2 border-t border-neutral-800/80 bg-neutral-900/60 text-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-neutral-300">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="font-mono text-[11px] text-neutral-300">
                  {liveSuggestions[0].message}
                </span>
              </div>
              <button
                onClick={handleAutoMinify}
                className="px-2 py-0.5 text-[11px] font-mono text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 rounded border border-amber-500/30 shrink-0"
              >
                Apply Minify
              </button>
            </div>
          )}

          {/* Action Footer: Run Tests & Submit to Colosseum */}
          <div className="flex items-center justify-between px-4 py-3 bg-neutral-950 border-t border-neutral-800">
            <button
              onClick={handleRunTests}
              disabled={isRunning}
              className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-neutral-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 rounded-lg transition-colors shadow-sm"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isRunning ? 'Executing Sandbox...' : 'Run Test Suite'}</span>
            </button>

            <div className="flex items-center gap-3">
              {report && report.allPassed && (
                <button
                  onClick={handleSubmit}
                  disabled={hasSubmitted}
                  className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-colors ${
                    hasSubmitted
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 cursor-default'
                      : 'bg-emerald-500 hover:bg-emerald-400 text-neutral-950 shadow-sm'
                  }`}
                >
                  <Award className="w-4 h-4" />
                  <span>{hasSubmitted ? 'Submitted to Bracket!' : 'Submit to Leaderboard'}</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Special Brainfuck Tape Visualizer when Brainfuck bracket is selected */}
        {selectedLanguage === 'brainfuck' && (
          <BrainfuckTapeViewer code={code} sampleInput="GOLF" />
        )}

        {/* Execution Report Drawer */}
        {report && (
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 space-y-3 shadow-sm">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center gap-2">
                {report.allPassed ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-400" />
                )}
                <div>
                  <h4 className="text-sm font-semibold text-neutral-100">
                    {report.allPassed
                      ? 'All Test Cases Passed!'
                      : `Failed (${report.passedTests}/${report.totalTests} Passed)`}
                  </h4>
                  <p className="text-xs text-neutral-400">
                    Execution time: <span className="text-neutral-200 font-mono tabular-nums">{report.totalTimeMs}ms</span> · Byte weight: <span className="text-neutral-200 font-mono tabular-nums">{report.byteCount} Bytes</span>
                  </p>
                </div>
              </div>

              {report.allPassed && (
                <div className="text-right">
                  <div className="text-xs font-semibold text-emerald-400">Passed Colosseum Verification</div>
                  <div className="text-[11px] text-neutral-400 font-mono">Eligible for leaderboard placement</div>
                </div>
              )}
            </div>

            {report.error && (
              <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs font-mono">
                {report.error}
              </div>
            )}

            {/* Individual Test Breakdown */}
            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
              {report.results.map((res, i) => (
                <div
                  key={res.testId}
                  className={`p-2.5 rounded-lg border text-xs font-mono space-y-1 ${
                    res.passed
                      ? 'bg-neutral-950/60 border-neutral-800/80 text-neutral-300'
                      : 'bg-rose-950/20 border-rose-800/40 text-rose-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-neutral-200">
                      {res.name} {res.isHidden && '(Hidden Edge Case)'}
                    </span>
                    <span className={`text-[11px] font-bold ${res.passed ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {res.passed ? `PASSED (${res.executionTimeMs}ms)` : 'FAILED'}
                    </span>
                  </div>

                  {!res.passed && (
                    <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                      <div>
                        <span className="text-neutral-500 block">Expected:</span>
                        <code className="text-neutral-300">{JSON.stringify(res.expected)}</code>
                      </div>
                      <div>
                        <span className="text-neutral-500 block">Actual:</span>
                        <code className="text-rose-400">{JSON.stringify(res.actual)}</code>
                      </div>
                      {res.error && (
                        <div className="col-span-2 text-rose-400">Error: {res.error}</div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
