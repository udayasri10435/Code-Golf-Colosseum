import React from 'react';
import { UserGladiatorProfile } from '../data/leaderboard';
import { Trophy, Swords, BookOpen } from 'lucide-react';

export type NavTab = 'arena' | 'leaderboard' | 'tournament' | 'duel';

interface TopBarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenGrimoire: () => void;
  userProfile: UserGladiatorProfile;
  totalSolved: number;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  onSelectTab,
  onOpenGrimoire,
  userProfile,
  totalSolved
}) => {
  return (
    <header className="flex items-center justify-between px-6 py-3.5 border-b border-neutral-800/80 bg-neutral-950/90 backdrop-blur-md sticky top-0 z-40">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3">
        <a
          href="#arena"
          onClick={e => {
            e.preventDefault();
            onSelectTab('arena');
          }}
          className="text-base font-bold tracking-tight text-neutral-100 flex items-center gap-2 group"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-sm shadow-amber-500/50 group-hover:scale-125 transition-transform" />
          <span>Code Golf Colosseum</span>
        </a>
      </div>

      {/* Zone 2: 4-6 clean text navigation links */}
      <nav className="hidden md:flex items-center gap-7 text-xs font-medium text-neutral-400">
        <button
          onClick={() => onSelectTab('arena')}
          className={`transition-colors hover:text-neutral-100 whitespace-nowrap ${
            activeTab === 'arena' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          Arena
        </button>
        <button
          onClick={() => onSelectTab('leaderboard')}
          className={`transition-colors hover:text-neutral-100 whitespace-nowrap ${
            activeTab === 'leaderboard' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          Leaderboard & Brackets
        </button>
        <button
          onClick={() => onSelectTab('tournament')}
          className={`transition-colors hover:text-neutral-100 whitespace-nowrap ${
            activeTab === 'tournament' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          Tournament Bracket
        </button>
        <button
          onClick={() => onSelectTab('duel')}
          className={`transition-colors hover:text-neutral-100 whitespace-nowrap ${
            activeTab === 'duel' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          Gladiator Duel
        </button>
      </nav>

      {/* Zone 3: 1-2 primary actions */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenGrimoire}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:text-neutral-100 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-lg transition-colors whitespace-nowrap"
          title="Open Grimoire of Golf Tricks"
        >
          <BookOpen className="w-3.5 h-3.5 text-amber-500" />
          <span>Golf Grimoire</span>
        </button>

        <div className="flex items-center gap-2 pl-2 border-l border-neutral-800 text-xs font-mono text-neutral-400">
          <div className="flex items-center gap-1.5 text-neutral-300">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span className="tabular-nums font-semibold text-neutral-100">{totalSolved}</span>
            <span className="text-[11px] text-neutral-500 hidden sm:inline">cleared</span>
          </div>
          <span className="text-neutral-600 hidden sm:inline">/</span>
          <span className="text-[11px] text-amber-400/90 font-sans hidden sm:inline">{userProfile.handle}</span>
        </div>
      </div>
    </header>
  );
};
