import { LeaderboardEntry, LanguageBracket, TournamentMatch } from '../types/golf';

const STORAGE_KEY = 'colosseum_golf_leaderboards_v2';
const USER_PROFILE_KEY = 'colosseum_user_profile_v2';

export const INITIAL_LEADERBOARD: LeaderboardEntry[] = [
  // FizzBuzz Royale - JavaScript
  {
    id: 'entry-fb-js-1',
    challengeId: 'fizzbuzz',
    gladiatorName: 'ByteSlayer_99',
    avatarSeed: 'gladiator-1',
    badge: 'Champion',
    language: 'javascript',
    bytes: 47,
    charCount: 47,
    executionTimeMs: 1.2,
    submittedAt: '12m ago',
    code: 'n=>[...Array(n)].map((_,i)=>(++i%3?"":"Fizz")+(i%5?"":"Buzz")||i)',
    upvotes: 42
  },
  {
    id: 'entry-fb-js-2',
    challengeId: 'fizzbuzz',
    gladiatorName: 'MinifyMax',
    avatarSeed: 'gladiator-2',
    badge: 'Gold',
    language: 'javascript',
    bytes: 54,
    charCount: 54,
    executionTimeMs: 1.8,
    submittedAt: '1h ago',
    code: 'n=>Array(n).fill().map((_,i)=>(++i%15?i%5?i%3?i:"Fizz":"Buzz":"FizzBuzz"))',
    upvotes: 28
  },
  {
    id: 'entry-fb-py-1',
    challengeId: 'fizzbuzz',
    gladiatorName: 'PyPythonic',
    avatarSeed: 'gladiator-3',
    badge: 'Champion',
    language: 'python',
    bytes: 49,
    charCount: 49,
    executionTimeMs: 2.1,
    submittedAt: '35m ago',
    code: 'lambda n:[("Fizz"*(i%3<1)+"Buzz"*(i%5<1))or i for i in range(1,n+1)]',
    upvotes: 39
  },

  // Prime Sieve Oracle
  {
    id: 'entry-prime-js-1',
    challengeId: 'isprime',
    gladiatorName: 'RegexDemon',
    avatarSeed: 'gladiator-4',
    badge: 'Champion',
    language: 'javascript',
    bytes: 31,
    charCount: 31,
    executionTimeMs: 0.8,
    submittedAt: '4h ago',
    code: 'n=>!/^1?$|^(11+?)\\1+$/.test("1".repeat(n))',
    upvotes: 88
  },
  {
    id: 'entry-prime-js-2',
    challengeId: 'isprime',
    gladiatorName: 'RecursionWarden',
    avatarSeed: 'gladiator-5',
    badge: 'Gold',
    language: 'javascript',
    bytes: 36,
    charCount: 36,
    executionTimeMs: 0.5,
    submittedAt: '6h ago',
    code: 'p=(n,i=2)=>i*i>n||(n%i&&p(n,i+1))',
    upvotes: 31
  },
  {
    id: 'entry-prime-py-1',
    challengeId: 'isprime',
    gladiatorName: 'ZenOfGolf',
    avatarSeed: 'gladiator-6',
    badge: 'Champion',
    language: 'python',
    bytes: 34,
    charCount: 34,
    executionTimeMs: 1.4,
    submittedAt: '2h ago',
    code: 'lambda n:n>1 and all(n%i for i in range(2,n))',
    upvotes: 45
  },

  // Palindromic Anagram
  {
    id: 'entry-pal-py-1',
    challengeId: 'palindrome_perm',
    gladiatorName: 'SetTheorist',
    avatarSeed: 'gladiator-7',
    badge: 'Champion',
    language: 'python',
    bytes: 47,
    charCount: 47,
    executionTimeMs: 1.1,
    submittedAt: '3h ago',
    code: 'lambda s:sum(s.count(c)%2 for c in set(s))<=1',
    upvotes: 56
  },
  {
    id: 'entry-pal-js-1',
    challengeId: 'palindrome_perm',
    gladiatorName: 'BitTwiddler',
    avatarSeed: 'gladiator-8',
    badge: 'Gold',
    language: 'javascript',
    bytes: 52,
    charCount: 52,
    executionTimeMs: 0.9,
    submittedAt: '5h ago',
    code: 's=>new Set([...s].filter(c=>[...s].filter(x=>x==c).length%2)).size<2',
    upvotes: 33
  },

  // Run-Length Encoder
  {
    id: 'entry-rle-js-1',
    challengeId: 'rle',
    gladiatorName: 'RegexDemon',
    avatarSeed: 'gladiator-4',
    badge: 'Champion',
    language: 'javascript',
    bytes: 35,
    charCount: 35,
    executionTimeMs: 0.6,
    submittedAt: '1d ago',
    code: 's=>s.replace(/(.)\\1*/g,m=>m[0]+m.length)',
    upvotes: 94
  },
  {
    id: 'entry-rle-py-1',
    challengeId: 'rle',
    gladiatorName: 'ItertoolsAscendant',
    avatarSeed: 'gladiator-9',
    badge: 'Gold',
    language: 'python',
    bytes: 44,
    charCount: 44,
    executionTimeMs: 2.2,
    submittedAt: '8h ago',
    code: 'lambda s:"".join(m[0]+str(len(m)) for m in __import__("re").findall(r"((.)\\2*)",s))',
    upvotes: 27
  },

  // Spiral Matrix Unravel
  {
    id: 'entry-sp-py-1',
    challengeId: 'spiral',
    gladiatorName: 'MatrixWhisperer',
    avatarSeed: 'gladiator-10',
    badge: 'Champion',
    language: 'python',
    bytes: 49,
    charCount: 49,
    executionTimeMs: 1.9,
    submittedAt: '12h ago',
    code: 'f=lambda m:m and[*m.pop(0)]+f([*zip(*m)][::-1])',
    upvotes: 112
  },
  {
    id: 'entry-sp-js-1',
    challengeId: 'spiral',
    gladiatorName: 'ArraySurgeon',
    avatarSeed: 'gladiator-11',
    badge: 'Champion',
    language: 'javascript',
    bytes: 68,
    charCount: 68,
    executionTimeMs: 1.5,
    submittedAt: '7h ago',
    code: 'f=m=>m[0]?[...m.shift(),...f(m[0]?m[0].map((_,i)=>m.map(r=>r[i]).reverse()):[])]:[]',
    upvotes: 62
  },

  // Brainfuck Oracle
  {
    id: 'entry-bf-1',
    challengeId: 'brainfuck_echo',
    gladiatorName: 'TapeGladiator',
    avatarSeed: 'gladiator-12',
    badge: 'Champion',
    language: 'brainfuck',
    bytes: 5,
    charCount: 5,
    executionTimeMs: 0.2,
    submittedAt: '2d ago',
    code: ',[.,]',
    upvotes: 140
  },
  {
    id: 'entry-bf-2',
    challengeId: 'brainfuck_echo',
    gladiatorName: 'EsolangMystic',
    avatarSeed: 'gladiator-13',
    badge: 'Gold',
    language: 'brainfuck',
    bytes: 7,
    charCount: 7,
    executionTimeMs: 0.3,
    submittedAt: '1d ago',
    code: '+[,.[-],]',
    upvotes: 38
  }
];

export const INITIAL_TOURNAMENT_MATCHES: TournamentMatch[] = [
  {
    id: 'tm-1',
    round: 'Quarterfinals',
    challengeTitle: 'FizzBuzz Royale',
    gladiatorA: {
      name: 'ByteSlayer_99',
      avatarSeed: 'gladiator-1',
      bytes: 47,
      language: 'javascript',
      passed: true
    },
    gladiatorB: {
      name: 'MinifyMax',
      avatarSeed: 'gladiator-2',
      bytes: 54,
      language: 'javascript',
      passed: true
    },
    winnerId: 'ByteSlayer_99',
    status: 'completed'
  },
  {
    id: 'tm-2',
    round: 'Quarterfinals',
    challengeTitle: 'Prime Sieve Oracle',
    gladiatorA: {
      name: 'RegexDemon',
      avatarSeed: 'gladiator-4',
      bytes: 31,
      language: 'javascript',
      passed: true
    },
    gladiatorB: {
      name: 'RecursionWarden',
      avatarSeed: 'gladiator-5',
      bytes: 36,
      language: 'javascript',
      passed: true
    },
    winnerId: 'RegexDemon',
    status: 'completed'
  },
  {
    id: 'tm-3',
    round: 'Semifinals',
    challengeTitle: 'Run-Length Encoder',
    gladiatorA: {
      name: 'ByteSlayer_99',
      avatarSeed: 'gladiator-1',
      bytes: 38,
      language: 'javascript',
      passed: true
    },
    gladiatorB: {
      name: 'RegexDemon',
      avatarSeed: 'gladiator-4',
      bytes: 35,
      language: 'javascript',
      passed: true
    },
    winnerId: 'RegexDemon',
    status: 'completed'
  },
  {
    id: 'tm-4',
    round: 'Grand Finals',
    challengeTitle: 'Spiral Matrix Unravel',
    gladiatorA: {
      name: 'RegexDemon',
      avatarSeed: 'gladiator-4',
      bytes: 58,
      language: 'javascript',
      passed: true
    },
    gladiatorB: {
      name: 'You (Gladiator Challenger)',
      avatarSeed: 'user-gladiator',
      bytes: 0,
      language: 'javascript',
      passed: false
    },
    status: 'live'
  }
];

export function getStoredLeaderboard(): LeaderboardEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return INITIAL_LEADERBOARD;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : INITIAL_LEADERBOARD;
  } catch {
    return INITIAL_LEADERBOARD;
  }
}

export function saveLeaderboardEntry(entry: LeaderboardEntry): LeaderboardEntry[] {
  const current = getStoredLeaderboard();
  // Check if user already has an entry for this challenge & language
  const existingIdx = current.findIndex(
    e => e.challengeId === entry.challengeId && e.language === entry.language && e.isUser
  );

  let updated: LeaderboardEntry[];
  if (existingIdx !== -1) {
    // Only update if fewer bytes or same bytes
    if (entry.bytes <= current[existingIdx].bytes) {
      updated = [...current];
      updated[existingIdx] = entry;
    } else {
      updated = current;
    }
  } else {
    updated = [entry, ...current];
  }

  // Sort by bytes ascending
  updated.sort((a, b) => a.bytes - b.bytes);

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to store leaderboard', e);
  }
  return updated;
}

export interface UserGladiatorProfile {
  handle: string;
  avatarSeed: string;
  totalSubmissions: number;
  solvedChallenges: string[];
  bestBytesRecord: number;
  colosseumRank: string;
  trophiesCount: number;
}

export function getUserProfile(): UserGladiatorProfile {
  try {
    const raw = localStorage.getItem(USER_PROFILE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {
    handle: 'Gladiator_Prime',
    avatarSeed: 'user-prime',
    totalSubmissions: 0,
    solvedChallenges: [],
    bestBytesRecord: 999,
    colosseumRank: 'Novice Duelist',
    trophiesCount: 0
  };
}

export function saveUserProfile(profile: UserGladiatorProfile): void {
  try {
    localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(profile));
  } catch {}
}
