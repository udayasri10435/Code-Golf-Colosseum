import { GolfTrick } from '../types/golf';

export const GOLF_TRICKS: GolfTrick[] = [
  {
    title: 'Bitwise Truncation / Floor',
    language: 'javascript',
    category: 'Math',
    bytesSaved: 'Save 9 to 11 bytes',
    before: 'Math.floor(x)',
    after: 'x|0  or  ~~x',
    explanation: 'Bitwise OR with 0 converts a 64-bit float to a signed 32-bit integer, effectively truncating positive fractional values in 3 characters.'
  },
  {
    title: 'Unary Plus for Number Parsing',
    language: 'javascript',
    category: 'Type Coercion',
    bytesSaved: 'Save 6 bytes',
    before: 'Number(str) or parseInt(str)',
    after: '+str',
    explanation: 'The unary plus operator coerces string representations of numbers directly into numeric primitives with zero overhead.'
  },
  {
    title: 'Empty String Concatenation',
    language: 'javascript',
    category: 'Type Coercion',
    bytesSaved: 'Save 5 bytes',
    before: 'String(num) or num.toString()',
    after: '""+num',
    explanation: 'Concatenating with an empty string or template string `${num}` triggers implicit string coercion.'
  },
  {
    title: 'Implicit Arrow Returns',
    language: 'javascript',
    category: 'Functions',
    bytesSaved: 'Save 16+ bytes',
    before: 'function(x){return x*2;}',
    after: 'x=>x*2',
    explanation: 'Single argument arrow functions omit parentheses, braces, and the `return` keyword completely.'
  },
  {
    title: 'Regex Backreference Compression',
    language: 'javascript',
    category: 'Strings',
    bytesSaved: 'Save 30+ bytes',
    before: 'for(let i=0;...){if(s[i]==s[i+1])...}',
    after: 's.replace(/(.)\\1*/g,m=>...)',
    explanation: 'Using regex backreference `\\1*` matches consecutive identical characters in a single declarative stroke.'
  },
  {
    title: 'Short-Circuit Default Assignment',
    language: 'javascript',
    category: 'Logic',
    bytesSaved: 'Save 8 bytes',
    before: 'val !== null ? val : 10',
    after: 'val||10',
    explanation: 'Logical OR `||` falls through on falsy values (0, "", null, undefined), eliminating ternary operators.'
  },
  {
    title: 'Python Slice Reversal',
    language: 'python',
    category: 'Strings',
    bytesSaved: 'Save 18 bytes',
    before: '"".join(reversed(s))',
    after: 's[::-1]',
    explanation: 'The negative step slice `[::-1]` reverses any sequence in 7 concise characters.'
  },
  {
    title: 'Python Modulo String Multiplexer',
    language: 'python',
    category: 'Logic',
    bytesSaved: 'Save 25 bytes',
    before: 'if i%15==0:"FizzBuzz" elif i%3==0:"Fizz"...',
    after: '"Fizz"*(i%3==0)+"Buzz"*(i%5==0) or i',
    explanation: 'Multiplying a string by a boolean condition either yields the string or empty string `""`. Falling back with `or` produces numbers.'
  },
  {
    title: 'Python Star-Unpacking Zip Transpose',
    language: 'python',
    category: 'Arrays',
    bytesSaved: 'Save 35 bytes',
    before: '[[r[c] for r in m] for c in range(len(m[0]))]',
    after: '[*zip(*m)]',
    explanation: 'Unpacking rows into `zip(*m)` transposes any 2D matrix in a single breath.'
  },
  {
    title: 'Brainfuck Cell Zeroing Loop',
    language: 'brainfuck',
    category: 'Memory Management',
    bytesSaved: 'Canonical 3 bytes',
    before: '----------------... (count to zero)',
    after: '[-]',
    explanation: 'Decrements the current cell until zero is reached, instantly clearing the register regardless of previous value.'
  },
  {
    title: 'Brainfuck Addition / Move Loop',
    language: 'brainfuck',
    category: 'Math',
    bytesSaved: 'Save 20+ bytes',
    before: 'Hardcoded increments in target cell',
    after: '[->+<]',
    explanation: 'Transfers the numeric value of the current cell to the adjacent right cell, leaving current cell at 0.'
  },
  {
    title: 'Brainfuck Canonical Echo Filter',
    language: 'brainfuck',
    category: 'I/O',
    bytesSaved: 'Save 12 bytes',
    before: '+[-,.[-],]',
    after: ',[.,]',
    explanation: 'The classic 5-character loop: reads a byte `,`, while non-zero enters `[` outputs `.` reads next `,` and repeats `]`.'
  }
];
