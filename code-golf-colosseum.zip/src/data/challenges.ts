import { Challenge } from '../types/golf';

export const CHALLENGES: Challenge[] = [
  {
    id: 'fizzbuzz',
    title: 'FizzBuzz Royale',
    slug: 'fizzbuzz-royale',
    category: 'Logic',
    difficulty: 'Novice',
    description: 'Write a function taking an integer n (1 <= n <= 100) and returning an array of strings/numbers from 1 to n. Multiples of 3 are "Fizz", multiples of 5 are "Buzz", multiples of both 15 are "FizzBuzz", otherwise the number.',
    functionName: 'fizzbuzz',
    supportedLanguages: ['javascript', 'python'],
    pars: {
      javascript: { par: 68, birdie: 58, eagle: 50, albatross: 45, holeInOne: 39 },
      python: { par: 75, birdie: 64, eagle: 55, albatross: 48, holeInOne: 42 },
      brainfuck: { par: 300, birdie: 250, eagle: 200, albatross: 180, holeInOne: 150 },
      regex: { par: 50, birdie: 40, eagle: 32, albatross: 28, holeInOne: 24 }
    },
    visibleTests: [
      {
        id: 'fb-1',
        name: 'Small Sequence (n=5)',
        input: [5],
        expected: [1, 2, 'Fizz', 4, 'Buzz']
      },
      {
        id: 'fb-2',
        name: 'Includes FizzBuzz (n=15)',
        input: [15],
        expected: [1, 2, 'Fizz', 4, 'Buzz', 'Fizz', 7, 8, 'Fizz', 'Buzz', 11, 'Fizz', 13, 14, 'FizzBuzz']
      }
    ],
    hiddenTests: [
      {
        id: 'fb-h1',
        name: 'Single Element (n=1)',
        input: [1],
        expected: [1],
        isHidden: true
      },
      {
        id: 'fb-h2',
        name: 'Edge multiple (n=30)',
        input: [30],
        expected: [
          1, 2, 'Fizz', 4, 'Buzz', 'Fizz', 7, 8, 'Fizz', 'Buzz',
          11, 'Fizz', 13, 14, 'FizzBuzz', 16, 17, 'Fizz', 19, 'Buzz',
          'Fizz', 22, 23, 'Fizz', 'Buzz', 26, 'Fizz', 28, 29, 'FizzBuzz'
        ],
        isHidden: true
      }
    ],
    starterCode: {
      javascript: `// Write arrow function: n => array
n => Array.from({length: n}, (_, i) => {
  const k = i + 1;
  return (k % 15 === 0 ? "FizzBuzz" : k % 3 === 0 ? "Fizz" : k % 5 === 0 ? "Buzz" : k);
})`,
      python: `# Return list for 1..n
lambda n: [("Fizz"*(i%3==0) + "Buzz"*(i%5==0)) or i for i in range(1, n+1)]`,
      brainfuck: ``,
      regex: ``
    },
    standardVerboseCode: {
      javascript: `function fizzbuzz(n) {
  const result = [];
  for (let i = 1; i <= n; i++) {
    if (i % 15 === 0) result.push("FizzBuzz");
    else if (i % 3 === 0) result.push("Fizz");
    else if (i % 5 === 0) result.push("Buzz");
    else result.push(i);
  }
  return result;
}`,
      python: `def fizzbuzz(n):
    res = []
    for i in range(1, n + 1):
        if i % 15 == 0:
            res.append("FizzBuzz")
        elif i % 3 == 0:
            res.append("Fizz")
        elif i % 5 == 0:
            res.append("Buzz")
        else:
            res.append(i)
    return res`,
      brainfuck: ``,
      regex: ``
    },
    tips: [
      'Use modulo string multiplication: ("Fizz"*(i%3==0) + "Buzz"*(i%5==0)) || i',
      'In JS, map array with `Array(n).fill().map((_,i)=>...)` or recursion `f=(n,a=[])=>n?f(n-1,[...a,n]):a`',
      'Bitwise trick: `(++i%3?"":"Fizz")+(i%5?"":"Buzz")||i`'
    ]
  },
  {
    id: 'isprime',
    title: 'Prime Sieve Oracle',
    slug: 'prime-sieve-oracle',
    category: 'Math',
    difficulty: 'Gladiator',
    description: 'Determine whether a given positive integer n is a prime number. Return boolean true/false (or 1/0). Numbers <= 1 are not prime.',
    functionName: 'isPrime',
    supportedLanguages: ['javascript', 'python'],
    pars: {
      javascript: { par: 46, birdie: 38, eagle: 32, albatross: 27, holeInOne: 23 },
      python: { par: 50, birdie: 42, eagle: 36, albatross: 30, holeInOne: 26 },
      brainfuck: { par: 200, birdie: 150, eagle: 120, albatross: 90, holeInOne: 70 },
      regex: { par: 35, birdie: 28, eagle: 24, albatross: 20, holeInOne: 17 }
    },
    visibleTests: [
      {
        id: 'p-1',
        name: 'Small Non-Prime (n=4)',
        input: [4],
        expected: false
      },
      {
        id: 'p-2',
        name: 'Small Prime (n=7)',
        input: [7],
        expected: true
      },
      {
        id: 'p-3',
        name: 'One (n=1 is not prime)',
        input: [1],
        expected: false
      }
    ],
    hiddenTests: [
      {
        id: 'p-h1',
        name: 'Two (n=2 smallest prime)',
        input: [2],
        expected: true,
        isHidden: true
      },
      {
        id: 'p-h2',
        name: 'Medium composite (n=49)',
        input: [49],
        expected: false,
        isHidden: true
      },
      {
        id: 'p-h3',
        name: 'Larger prime (n=97)',
        input: [97],
        expected: true,
        isHidden: true
      }
    ],
    starterCode: {
      javascript: `// Return true/false if n is prime
n => {
  if (n < 2) return false;
  for (let i = 2; i * i <= n; i++) {
    if (n % i === 0) return false;
  }
  return true;
}`,
      python: `# Lambda returning true/false
lambda n: n > 1 and all(n % i != 0 for i in range(2, int(n**0.5) + 1))`,
      brainfuck: ``,
      regex: ``
    },
    standardVerboseCode: {
      javascript: `function isPrime(n) {
  if (n <= 1) return false;
  for (let i = 2; i <= Math.sqrt(n); i++) {
    if (n % i === 0) return false;
  }
  return true;
}`,
      python: `def isPrime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True`,
      brainfuck: ``,
      regex: ``
    },
    tips: [
      'Regex prime trick in JS: `!/^1?$|^(11+?)\\1+$/.test("1".repeat(n))` (29 bytes!)',
      'Recursive golf: `p=(n,i=2)=>i*i>n||n%i&&p(n,i+1)` (34 bytes!)',
      'Python: `all(n%i for i in range(2,n)) and n>1`'
    ]
  },
  {
    id: 'palindrome_perm',
    title: 'Palindromic Anagram',
    slug: 'palindromic-anagram',
    category: 'Strings',
    difficulty: 'Gladiator',
    description: 'Given a string s consisting of lowercase letters, return true if any permutation of its characters can form a palindrome, false otherwise.',
    functionName: 'canFormPalindrome',
    supportedLanguages: ['javascript', 'python'],
    pars: {
      javascript: { par: 65, birdie: 54, eagle: 46, albatross: 39, holeInOne: 34 },
      python: { par: 68, birdie: 56, eagle: 48, albatross: 42, holeInOne: 36 },
      brainfuck: { par: 180, birdie: 140, eagle: 110, albatross: 85, holeInOne: 65 },
      regex: { par: 60, birdie: 50, eagle: 42, albatross: 35, holeInOne: 30 }
    },
    visibleTests: [
      {
        id: 'pp-1',
        name: 'Even palindrome anagram ("carrace")',
        input: ['carrace'],
        expected: true
      },
      {
        id: 'pp-2',
        name: 'Impossible ("daily")',
        input: ['daily'],
        expected: false
      }
    ],
    hiddenTests: [
      {
        id: 'pp-h1',
        name: 'Empty string ("")',
        input: [''],
        expected: true,
        isHidden: true
      },
      {
        id: 'pp-h2',
        name: 'Single character ("z")',
        input: ['z'],
        expected: true,
        isHidden: true
      },
      {
        id: 'pp-h3',
        name: 'Repeated odd count ("aabbccc")',
        input: ['aabbccc'],
        expected: true,
        isHidden: true
      }
    ],
    starterCode: {
      javascript: `// Check if anagram can form palindrome
s => {
  const set = new Set();
  for (const c of s) set.has(c) ? set.delete(c) : set.add(c);
  return set.size <= 1;
}`,
      python: `# Python lambda
lambda s: sum(s.count(c)%2 for c in set(s)) <= 1`,
      brainfuck: ``,
      regex: ``
    },
    standardVerboseCode: {
      javascript: `function canFormPalindrome(s) {
  const counts = {};
  for (const char of s) counts[char] = (counts[char] || 0) + 1;
  let oddCount = 0;
  for (const count of Object.values(counts)) {
    if (count % 2 !== 0) oddCount++;
  }
  return oddCount <= 1;
}`,
      python: `def canFormPalindrome(s):
    counts = {}
    for c in s:
        counts[c] = counts.get(c, 0) + 1
    return sum(v % 2 for v in counts.values()) <= 1`,
      brainfuck: ``,
      regex: ``
    },
    tips: [
      'In Python: `lambda s:sum(s.count(c)%2 for c in set(s))<=1` is just 47 bytes!',
      'In JS, bitwise XOR on character code powers can toggle parity bits!'
    ]
  },
  {
    id: 'roman',
    title: 'Roman Numeral Forge',
    slug: 'roman-numeral-forge',
    category: 'Math',
    difficulty: 'Centurion',
    description: 'Convert a positive integer n (1 <= n <= 3999) to its standard Roman numeral string representation (e.g. 1994 -> "MCMXCIV").',
    functionName: 'toRoman',
    supportedLanguages: ['javascript', 'python'],
    pars: {
      javascript: { par: 92, birdie: 80, eagle: 70, albatross: 62, holeInOne: 54 },
      python: { par: 98, birdie: 86, eagle: 75, albatross: 66, holeInOne: 58 },
      brainfuck: { par: 400, birdie: 320, eagle: 250, albatross: 200, holeInOne: 170 },
      regex: { par: 80, birdie: 70, eagle: 60, albatross: 52, holeInOne: 45 }
    },
    visibleTests: [
      {
        id: 'r-1',
        name: 'Basic addition (n=58)',
        input: [58],
        expected: 'LVIII'
      },
      {
        id: 'r-2',
        name: 'Subtractive notation (n=1994)',
        input: [1994],
        expected: 'MCMXCIV'
      }
    ],
    hiddenTests: [
      {
        id: 'r-h1',
        name: 'Single unit (n=4)',
        input: [4],
        expected: 'IV',
        isHidden: true
      },
      {
        id: 'r-h2',
        name: 'Upper boundary (n=3999)',
        input: [3999],
        expected: 'MMMCMXCIX',
        isHidden: true
      }
    ],
    starterCode: {
      javascript: `// Convert integer n to Roman string
n => {
  const map = {M:1000,CM:900,D:500,CD:400,C:100,XC:90,L:50,XL:40,X:10,IX:9,V:5,IV:4,I:1};
  let res = '';
  for (let k in map) {
    while (n >= map[k]) {
      res += k;
      n -= map[k];
    }
  }
  return res;
}`,
      python: `lambda n: "".join(r * ((n % 10**(i+1)) // 10**i) for i, r in enumerate(["I","X","C","M"]))`,
      brainfuck: ``,
      regex: ``
    },
    standardVerboseCode: {
      javascript: `function toRoman(n) {
  const vals = [1000,900,500,400,100,90,50,40,10,9,5,4,1];
  const syms = ["M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"];
  let out = "";
  for (let i = 0; i < vals.length; i++) {
    while (n >= vals[i]) {
      out += syms[i];
      n -= vals[i];
    }
  }
  return out;
}`,
      python: `def toRoman(n):
    lookup = [(1000,"M"),(900,"CM"),(500,"D"),(400,"CD"),(100,"C"),(90,"XC"),(50,"L"),(40,"XL"),(10,"X"),(9,"IX"),(5,"V"),(4,"IV"),(1,"I")]
    res = ""
    for val, sym in lookup:
        res += sym * (n // val)
        n %= val
    return res`,
      brainfuck: ``,
      regex: ``
    },
    tips: [
      'Lookup table string parsing: convert digits by index using digit lookup strings!',
      'In JS: `f=(n,s="")=>n>0?f(n-v,s+k):s` using recursive reduction'
    ]
  },
  {
    id: 'rle',
    title: 'Run-Length Encoder',
    slug: 'run-length-encoder',
    category: 'Strings',
    difficulty: 'Novice',
    description: 'Compress consecutive duplicate characters in string s into each character followed by its count (e.g. "aaabbc" -> "a3b2c1"). If string is empty, return "".',
    functionName: 'encodeRLE',
    supportedLanguages: ['javascript', 'python', 'regex'],
    pars: {
      javascript: { par: 52, birdie: 42, eagle: 34, albatross: 28, holeInOne: 23 },
      python: { par: 62, birdie: 52, eagle: 44, albatross: 38, holeInOne: 32 },
      brainfuck: { par: 250, birdie: 190, eagle: 150, albatross: 120, holeInOne: 95 },
      regex: { par: 30, birdie: 24, eagle: 20, albatross: 16, holeInOne: 13 }
    },
    visibleTests: [
      {
        id: 'rle-1',
        name: 'Repeated runs ("aaabbc")',
        input: ['aaabbc'],
        expected: 'a3b2c1'
      },
      {
        id: 'rle-2',
        name: 'Single characters ("abc")',
        input: ['abc'],
        expected: 'a1b1c1'
      }
    ],
    hiddenTests: [
      {
        id: 'rle-h1',
        name: 'Empty string ("")',
        input: [''],
        expected: '',
        isHidden: true
      },
      {
        id: 'rle-h2',
        name: 'Long streak ("zzzzzzzzzz")',
        input: ['zzzzzzzzzz'],
        expected: 'z10',
        isHidden: true
      }
    ],
    starterCode: {
      javascript: `// Compress runs: "aaabb" -> "a3b2"
s => s.replace(/(.)\\1*/g, m => m[0] + m.length)`,
      python: `# Python golf
lambda s: "".join(m[0]+str(len(m)) for m in __import__('re').findall(r'((.)\\2*)', s))`,
      brainfuck: ``,
      regex: `/(.)\\1*/g`
    },
    standardVerboseCode: {
      javascript: `function encodeRLE(s) {
  if (!s) return "";
  let out = "", count = 1;
  for (let i = 0; i < s.length; i++) {
    if (s[i] === s[i + 1]) count++;
    else {
      out += s[i] + count;
      count = 1;
    }
  }
  return out;
}`,
      python: `def encodeRLE(s):
    if not s: return ""
    import itertools
    return "".join(k + str(len(list(g))) for k, g in itertools.groupby(s))`,
      brainfuck: ``,
      regex: `/(.)\\1*/g`
    },
    tips: [
      'In JS: `s=>s.replace(/(.)\\1*/g,m=>m[0]+m.length)` is a master 36-byte one liner!',
      'Backreferences in regex `(.)\\1*` capture every repeated run in one swoop!'
    ]
  },
  {
    id: 'spiral',
    title: 'Spiral Matrix Unravel',
    slug: 'spiral-matrix-unravel',
    category: 'Arrays',
    difficulty: 'Titan',
    description: 'Given an m x n 2D array matrix of numbers, return all elements in clockwise spiral order as a single 1D array. Empty array returns [].',
    functionName: 'spiralOrder',
    supportedLanguages: ['javascript', 'python'],
    pars: {
      javascript: { par: 78, birdie: 66, eagle: 55, albatross: 47, holeInOne: 38 },
      python: { par: 65, birdie: 52, eagle: 42, albatross: 34, holeInOne: 28 },
      brainfuck: { par: 500, birdie: 400, eagle: 320, albatross: 260, holeInOne: 200 },
      regex: { par: 99, birdie: 99, eagle: 99, albatross: 99, holeInOne: 99 }
    },
    visibleTests: [
      {
        id: 'sp-1',
        name: '3x3 Matrix',
        input: [
          [
            [1, 2, 3],
            [4, 5, 6],
            [7, 8, 9]
          ]
        ],
        expected: [1, 2, 3, 6, 9, 8, 7, 4, 5]
      },
      {
        id: 'sp-2',
        name: '3x4 Rectangular Matrix',
        input: [
          [
            [1, 2, 3, 4],
            [5, 6, 7, 8],
            [9, 10, 11, 12]
          ]
        ],
        expected: [1, 2, 3, 4, 8, 12, 11, 10, 9, 5, 6, 7]
      }
    ],
    hiddenTests: [
      {
        id: 'sp-h1',
        name: 'Empty matrix',
        input: [[]],
        expected: [],
        isHidden: true
      },
      {
        id: 'sp-h2',
        name: 'Single row',
        input: [[[1, 2, 3, 4]]],
        expected: [1, 2, 3, 4],
        isHidden: true
      }
    ],
    starterCode: {
      javascript: `// Unravel spiral order
m => {
  const res = [];
  while (m.length) {
    res.push(...m.shift());
    m = m[0] ? m[0].map((_, i) => m.map(r => r[i]).reverse()) : [];
  }
  return res;
}`,
      python: `# Python matrix rotation golf
lambda m: m and [*m.pop(0)] + (lambda f: f(f, [list(x) for x in zip(*m)][::-1]))(lambda s, a: a and [*a.pop(0)] + s(s, [list(x) for x in zip(*a)][::-1]) if a else [])`,
      brainfuck: ``,
      regex: ``
    },
    standardVerboseCode: {
      javascript: `function spiralOrder(matrix) {
  if (!matrix.length) return [];
  let top = 0, bottom = matrix.length - 1;
  let left = 0, right = matrix[0].length - 1;
  const result = [];
  while (top <= bottom && left <= right) {
    for (let i = left; i <= right; i++) result.push(matrix[top][i]);
    top++;
    for (let i = top; i <= bottom; i++) result.push(matrix[i][right]);
    right--;
    if (top <= bottom) {
      for (let i = right; i >= left; i--) result.push(matrix[bottom][i]);
      bottom--;
    }
    if (left <= right) {
      for (let i = bottom; i >= top; i--) result.push(matrix[i][left]);
      left++;
    }
  }
  return result;
}`,
      python: `def spiralOrder(m):
    return m and [*m.pop(0)] + spiralOrder([*zip(*m)][::-1])`,
      brainfuck: ``,
      regex: ``
    },
    tips: [
      'Legendary recursive rotation golf: pop row 0, rotate rest of matrix 90 degrees counter-clockwise!',
      'In Python: `f=lambda m:m and[*m.pop(0)]+f([*zip(*m)][::-1])` (48 bytes!)'
    ]
  },
  {
    id: 'brainfuck_echo',
    title: 'The Oracle of Brainfuck',
    slug: 'oracle-of-brainfuck',
    category: 'Esolang',
    difficulty: 'Centurion',
    description: 'Write a Brainfuck program that reads an ASCII string from input `,` until EOF (0) and outputs each character reversed or uppercase or echoed. For this challenge: echo input characters directly to output `.`, stopping when input is null/0.',
    functionName: 'bfEcho',
    supportedLanguages: ['brainfuck', 'javascript'],
    pars: {
      brainfuck: { par: 12, birdie: 8, eagle: 6, albatross: 5, holeInOne: 4 },
      javascript: { par: 18, birdie: 14, eagle: 10, albatross: 8, holeInOne: 6 },
      python: { par: 20, birdie: 15, eagle: 12, albatross: 10, holeInOne: 8 },
      regex: { par: 15, birdie: 12, eagle: 10, albatross: 8, holeInOne: 6 }
    },
    visibleTests: [
      {
        id: 'bf-1',
        name: 'Echo "GOLF"',
        input: ['GOLF'],
        expected: 'GOLF'
      },
      {
        id: 'bf-2',
        name: 'Echo "COLOSSEUM 2026"',
        input: ['COLOSSEUM 2026'],
        expected: 'COLOSSEUM 2026'
      }
    ],
    hiddenTests: [
      {
        id: 'bf-h1',
        name: 'Single exclamation mark ("!")',
        input: ['!'],
        expected: '!',
        isHidden: true
      },
      {
        id: 'bf-h2',
        name: 'Empty string ("")',
        input: [''],
        expected: '',
        isHidden: true
      }
    ],
    starterCode: {
      brainfuck: `,[.,]`,
      javascript: `s=>s`,
      python: `lambda s: s`,
      regex: ``
    },
    standardVerboseCode: {
      brainfuck: `+[,.[-],]`,
      javascript: `function echo(s) { return s; }`,
      python: `def echo(s): return s`,
      regex: ``
    },
    tips: [
      'In Brainfuck, `,[.,]` is the canonical 5-byte echo loop: read char, output while non-zero, read next!'
    ]
  },
  {
    id: 'levenshtein',
    title: 'Levenshtein Edit Distance',
    slug: 'levenshtein-distance',
    category: 'Strings',
    difficulty: 'Titan',
    description: 'Calculate the minimum number of single-character edits (insertions, deletions or substitutions) required to change string a into string b.',
    functionName: 'levenshtein',
    supportedLanguages: ['javascript', 'python'],
    pars: {
      javascript: { par: 110, birdie: 95, eagle: 82, albatross: 72, holeInOne: 62 },
      python: { par: 115, birdie: 98, eagle: 85, albatross: 75, holeInOne: 65 },
      brainfuck: { par: 500, birdie: 420, eagle: 350, albatross: 290, holeInOne: 230 },
      regex: { par: 150, birdie: 120, eagle: 100, albatross: 80, holeInOne: 60 }
    },
    visibleTests: [
      {
        id: 'lev-1',
        name: '"kitten" -> "sitting"',
        input: ['kitten', 'sitting'],
        expected: 3
      },
      {
        id: 'lev-2',
        name: '"flaw" -> "lawn"',
        input: ['flaw', 'lawn'],
        expected: 2
      }
    ],
    hiddenTests: [
      {
        id: 'lev-h1',
        name: 'Identical strings ("golf", "golf")',
        input: ['golf', 'golf'],
        expected: 0,
        isHidden: true
      },
      {
        id: 'lev-h2',
        name: 'Empty first string ("", "a")',
        input: ['', 'a'],
        expected: 1,
        isHidden: true
      }
    ],
    starterCode: {
      javascript: `// Min edit distance between a and b
(a, b) => {
  const d = Array.from({length: a.length + 1}, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      d[i][j] = a[i-1] === b[j-1] ? d[i-1][j-1] : 1 + Math.min(d[i-1][j], d[i][j-1], d[i-1][j-1]);
    }
  }
  return d[a.length][b.length];
}`,
      python: `# Python recursive or DP golf
lambda a, b: (lambda f: f(f, len(a), len(b)))(lambda f, i, j: max(i, j) if not (i and j) else f(f, i-1, j-1) if a[i-1] == b[j-1] else 1 + min(f(f, i-1, j), f(f, i, j-1), f(f, i-1, j-1)))`,
      brainfuck: ``,
      regex: ``
    },
    standardVerboseCode: {
      javascript: `function levenshtein(a, b) {
  const matrix = [];
  for (let i = 0; i <= b.length; i++) matrix[i] = [i];
  for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
      }
    }
  }
  return matrix[b.length][a.length];
}`,
      python: `def levenshtein(a, b):
    dp = list(range(len(b) + 1))
    for i, c1 in enumerate(a):
        new_dp = [i + 1] * (len(b) + 1)
        for j, c2 in enumerate(b):
            cost = 0 if c1 == c2 else 1
            new_dp[j + 1] = min(dp[j + 1] + 1, new_dp[j] + 1, dp[j] + cost)
        dp = new_dp
    return dp[-1]`,
      brainfuck: ``,
      regex: ``
    },
    tips: [
      'In JS, 1D array reduction across characters can avoid allocating 2D matrix: `b.split("").reduce(...)`',
      'Recursive golf with default memo parameters'
    ]
  }
];
