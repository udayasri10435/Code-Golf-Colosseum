export type LanguageBracket = 'javascript' | 'python' | 'brainfuck' | 'regex';

export interface TestCase {
  id: string;
  name: string;
  input: any[];
  expected: any;
  description?: string;
  isHidden?: boolean;
}

export interface GolfPar {
  par: number;       // Standard par in bytes
  birdie: number;    // Under par
  eagle: number;     // Expert golf
  albatross: number; // Elite golf
  holeInOne: number; // Colosseum record
}

export interface Challenge {
  id: string;
  title: string;
  slug: string;
  category: 'Strings' | 'Math' | 'Arrays' | 'Logic' | 'Esolang';
  difficulty: 'Novice' | 'Gladiator' | 'Centurion' | 'Titan';
  description: string;
  functionName: string;
  supportedLanguages: LanguageBracket[];
  pars: Record<LanguageBracket, GolfPar>;
  visibleTests: TestCase[];
  hiddenTests: TestCase[];
  starterCode: Record<LanguageBracket, string>;
  standardVerboseCode: Record<LanguageBracket, string>;
  tips: string[];
}

export interface TestResult {
  testId: string;
  name: string;
  passed: boolean;
  actual: any;
  expected: any;
  executionTimeMs: number;
  error?: string;
  isHidden?: boolean;
  outputLog?: string[];
}

export interface ExecutionReport {
  allPassed: boolean;
  passedTests: number;
  totalTests: number;
  results: TestResult[];
  totalTimeMs: number;
  byteCount: number;
  charCount: number;
  gzipBytes: number;
  error?: string;
}

export interface LeaderboardEntry {
  id: string;
  challengeId: string;
  gladiatorName: string;
  avatarSeed: string;
  badge: 'Bronze' | 'Silver' | 'Gold' | 'Mythic' | 'Champion';
  language: LanguageBracket;
  bytes: number;
  charCount: number;
  executionTimeMs: number;
  submittedAt: string;
  code: string;
  isUser?: boolean;
  upvotes: number;
}

export interface TournamentMatch {
  id: string;
  round: 'Quarterfinals' | 'Semifinals' | 'Grand Finals';
  gladiatorA: {
    name: string;
    avatarSeed: string;
    bytes: number;
    language: LanguageBracket;
    passed: boolean;
  };
  gladiatorB: {
    name: string;
    avatarSeed: string;
    bytes: number;
    language: LanguageBracket;
    passed: boolean;
  };
  winnerId?: string;
  challengeTitle: string;
  status: 'upcoming' | 'live' | 'completed';
}

export interface GolfTrick {
  title: string;
  language: LanguageBracket;
  category: string;
  bytesSaved: string;
  before: string;
  after: string;
  explanation: string;
}
