import React, { useState, useEffect } from 'react';
import { CHALLENGES } from './data/challenges';
import {
  getStoredLeaderboard,
  saveLeaderboardEntry,
  getUserProfile,
  saveUserProfile,
  UserGladiatorProfile
} from './data/leaderboard';
import { Challenge, LanguageBracket, LeaderboardEntry } from './types/golf';
import { TopBar, NavTab } from './components/TopBar';
import { ArenaEditor } from './components/ArenaEditor';
import { LeaderboardView } from './components/LeaderboardView';
import { TournamentBrackets } from './components/TournamentBrackets';
import { DuelColosseum } from './components/DuelColosseum';
import { GolfGrimoireModal } from './components/GolfGrimoireModal';
import { Trophy, CheckCircle, Flame, Sparkles } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('arena');
  const [activeChallenge, setActiveChallenge] = useState<Challenge>(CHALLENGES[0]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(getStoredLeaderboard());
  const [userProfile, setUserProfile] = useState<UserGladiatorProfile>(getUserProfile());
  const [isGrimoireOpen, setIsGrimoireOpen] = useState(false);
  const [bannerToast, setBannerToast] = useState<{ title: string; message: string } | null>(null);

  // Sync profile when leaderboard updates
  const handleScoreSubmission = (
    challengeId: string,
    language: LanguageBracket,
    code: string,
    bytes: number,
    timeMs: number
  ) => {
    const entry: LeaderboardEntry = {
      id: `user-${challengeId}-${language}-${Date.now()}`,
      challengeId,
      gladiatorName: `${userProfile.handle} (You)`,
      avatarSeed: 'user-prime',
      badge: bytes <= (activeChallenge.pars[language]?.holeInOne || 50) ? 'Champion' : 'Gold',
      language,
      bytes,
      charCount: code.length,
      executionTimeMs: timeMs,
      submittedAt: 'Just now',
      code,
      isUser: true,
      upvotes: 1
    };

    const updated = saveLeaderboardEntry(entry);
    setLeaderboard(updated);

    // Update profile solved stats
    const solvedSet = new Set(userProfile.solvedChallenges);
    solvedSet.add(challengeId);
    const updatedProfile: UserGladiatorProfile = {
      ...userProfile,
      totalSubmissions: userProfile.totalSubmissions + 1,
      solvedChallenges: Array.from(solvedSet),
      bestBytesRecord: Math.min(userProfile.bestBytesRecord, bytes),
      trophiesCount: userProfile.trophiesCount + (bytes <= (activeChallenge.pars[language]?.birdie || 60) ? 1 : 0)
    };

    setUserProfile(updatedProfile);
    saveUserProfile(updatedProfile);

    // Show celebratory banner
    setBannerToast({
      title: 'Placement Recorded in Colosseum Brackets!',
      message: `Submitted ${bytes} Bytes on ${activeChallenge.title} (${language.toUpperCase()} bracket). Check your rank on the leaderboard!`
    });
    setTimeout(() => setBannerToast(null), 5000);
  };

  const handleLoadCodeIntoArena = (challengeId: string, language: LanguageBracket, code: string) => {
    const found = CHALLENGES.find(c => c.id === challengeId);
    if (found) {
      setActiveChallenge(found);
      setActiveTab('arena');
    }
  };

  const handleUpvoteEntry = (entryId: string) => {
    const updated = leaderboard.map(item => {
      if (item.id === entryId) {
        return { ...item, upvotes: item.upvotes + 1 };
      }
      return item;
    });
    setLeaderboard(updated);
  };

  const handleEnterTournamentMatch = (challengeTitle: string, targetBytes: number) => {
    const found = CHALLENGES.find(c => c.title.toLowerCase().includes(challengeTitle.toLowerCase())) || CHALLENGES[0];
    setActiveChallenge(found);
    setActiveTab('arena');
    setBannerToast({
      title: `Championship Round: Beat ${targetBytes} Bytes!`,
      message: `Optimize your solution below to conquer the reigning champion in ${found.title}.`
    });
    setTimeout(() => setBannerToast(null), 5000);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Bar with Strict 3-zone Contract */}
      <TopBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenGrimoire={() => setIsGrimoireOpen(true)}
        userProfile={userProfile}
        totalSolved={userProfile.solvedChallenges.length}
      />

      {/* Global Toast Notification */}
      {bannerToast && (
        <div className="bg-amber-500/10 border-b border-amber-500/30 px-6 py-2.5 flex items-center justify-between text-xs text-amber-300">
          <div className="flex items-center gap-2 max-w-4xl">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="font-semibold text-neutral-100">{bannerToast.title}</span>
            <span className="hidden sm:inline text-neutral-300">· {bannerToast.message}</span>
          </div>
          <button
            onClick={() => setBannerToast(null)}
            className="text-amber-400 hover:text-amber-200 font-semibold text-xs ml-4"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Viewport Content */}
      <main className="flex-1">
        {activeTab === 'arena' && (
          <ArenaEditor
            challenges={CHALLENGES}
            activeChallenge={activeChallenge}
            onSelectChallenge={setActiveChallenge}
            onSubmitScore={handleScoreSubmission}
          />
        )}

        {activeTab === 'leaderboard' && (
          <LeaderboardView
            entries={leaderboard}
            onLoadCodeIntoArena={handleLoadCodeIntoArena}
            onUpvoteEntry={handleUpvoteEntry}
          />
        )}

        {activeTab === 'tournament' && (
          <TournamentBrackets onEnterMatch={handleEnterTournamentMatch} />
        )}

        {activeTab === 'duel' && <DuelColosseum />}
      </main>

      {/* Golf Grimoire Modal */}
      <GolfGrimoireModal
        isOpen={isGrimoireOpen}
        onClose={() => setIsGrimoireOpen(false)}
      />

      {/* Footer */}
      <footer className="border-t border-neutral-900 bg-neutral-950 px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-neutral-500 font-mono">
        <div>Code Golf Colosseum · UTF-8 byte minimization arena</div>
        <div className="flex items-center gap-4 text-neutral-400">
          <span>JavaScript</span>
          <span>·</span>
          <span>Python</span>
          <span>·</span>
          <span>Brainfuck</span>
          <span>·</span>
          <span>Regex</span>
        </div>
      </footer>
    </div>
  );
}
