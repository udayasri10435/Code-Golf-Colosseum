import { GolfPar } from '../types/golf';

export interface GolfRating {
  tier: 'Hole-in-One' | 'Albatross' | 'Eagle' | 'Birdie' | 'Par' | 'Bogey' | 'Double Bogey';
  color: string;
  badgeBg: string;
  deltaToPar: number;
  description: string;
  strokeSymbol: string;
}

export interface GolfTipSuggestion {
  id: string;
  message: string;
  potentialSavings: number;
  fixable: boolean;
}

/**
 * Calculates golf score against par thresholds
 */
export function calculateGolfRating(bytes: number, par: GolfPar): GolfRating {
  if (bytes === 0) {
    return {
      tier: 'Par',
      color: 'text-neutral-400',
      badgeBg: 'bg-neutral-800',
      deltaToPar: 0,
      description: 'Awaiting submission',
      strokeSymbol: '—'
    };
  }

  const delta = bytes - par.par;

  if (bytes <= par.holeInOne) {
    return {
      tier: 'Hole-in-One',
      color: 'text-amber-400',
      badgeBg: 'bg-amber-500/10 border-amber-500/30 text-amber-300',
      deltaToPar: delta,
      description: 'Legendary efficiency! Colosseum record tier.',
      strokeSymbol: '★ -4'
    };
  }

  if (bytes <= par.albatross) {
    return {
      tier: 'Albatross',
      color: 'text-emerald-400',
      badgeBg: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300',
      deltaToPar: delta,
      description: 'Masterclass golf. In the top 1% bracket.',
      strokeSymbol: '-3'
    };
  }

  if (bytes <= par.eagle) {
    return {
      tier: 'Eagle',
      color: 'text-cyan-400',
      badgeBg: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300',
      deltaToPar: delta,
      description: 'Exceptional brevity. Grandmaster stroke.',
      strokeSymbol: '-2'
    };
  }

  if (bytes <= par.birdie) {
    return {
      tier: 'Birdie',
      color: 'text-blue-400',
      badgeBg: 'bg-blue-500/10 border-blue-500/30 text-blue-300',
      deltaToPar: delta,
      description: 'Crisp and clean under par.',
      strokeSymbol: '-1'
    };
  }

  if (bytes <= par.par) {
    return {
      tier: 'Par',
      color: 'text-neutral-300',
      badgeBg: 'bg-neutral-800 border-neutral-700 text-neutral-300',
      deltaToPar: delta,
      description: 'Standard benchmark achieved.',
      strokeSymbol: 'E'
    };
  }

  if (bytes <= par.par * 1.5) {
    return {
      tier: 'Bogey',
      color: 'text-orange-400',
      badgeBg: 'bg-orange-500/10 border-orange-500/30 text-orange-300',
      deltaToPar: delta,
      description: 'Functional but verbose. Shave some bytes!',
      strokeSymbol: '+1'
    };
  }

  return {
    tier: 'Double Bogey',
    color: 'text-rose-400',
    badgeBg: 'bg-rose-500/10 border-rose-500/30 text-rose-300',
    deltaToPar: delta,
    description: 'Bloated syntax. Heavy optimization needed.',
    strokeSymbol: '+2'
  };
}

/**
 * Scans code for common byte-saving optimizations
 */
export function analyzeGolfTricks(code: string, language: string): GolfTipSuggestion[] {
  const suggestions: GolfTipSuggestion[] = [];

  if (language === 'javascript') {
    if (code.includes('Math.floor(')) {
      suggestions.push({
        id: 'bitwise-floor',
        message: 'Replace Math.floor(x) with (x|0) or ~~x to save 9-11 bytes',
        potentialSavings: 9,
        fixable: true
      });
    }

    if (code.includes('Number(')) {
      suggestions.push({
        id: 'unary-plus',
        message: 'Replace Number(x) with +x to save 6 bytes',
        potentialSavings: 6,
        fixable: true
      });
    }

    if (code.includes('String(')) {
      suggestions.push({
        id: 'template-str',
        message: 'Replace String(x) with ""+x to save 5 bytes',
        potentialSavings: 5,
        fixable: true
      });
    }

    if (code.includes('function(') || code.includes('function (')) {
      suggestions.push({
        id: 'arrow-fn',
        message: 'Replace traditional function with arrow function `x=>...` to save ~12 bytes',
        potentialSavings: 12,
        fixable: false
      });
    }

    if (code.includes('===') || code.includes('!==')) {
      suggestions.push({
        id: 'loose-equality',
        message: 'In golf, == and != usually suffice, saving 1 byte per comparison',
        potentialSavings: 1,
        fixable: true
      });
    }

    if (/\s{2,}/.test(code) || code.includes('\n')) {
      const whitespaceBytes = (code.match(/\s/g) || []).length;
      if (whitespaceBytes > 3) {
        suggestions.push({
          id: 'minify-spaces',
          message: `Whitespace & linebreaks detected. Auto-minify can shave ~${whitespaceBytes} bytes`,
          potentialSavings: whitespaceBytes,
          fixable: true
        });
      }
    }
  }

  if (language === 'python') {
    if (code.includes('print(')) {
      suggestions.push({
        id: 'py-return',
        message: 'Return the value instead of printing to reduce payload and allow expression golf',
        potentialSavings: 4,
        fixable: false
      });
    }
    if (code.includes('def ')) {
      suggestions.push({
        id: 'py-lambda',
        message: 'Convert `def f(x): return ...` to `lambda x:...` for compact one-liners',
        potentialSavings: 8,
        fixable: false
      });
    }
  }

  if (language === 'brainfuck') {
    if (code.includes('[-]') === false && code.includes('+') && code.length > 50) {
      suggestions.push({
        id: 'bf-zero',
        message: 'Remember `[-]` rapidly zeroes a memory cell in 3 bytes',
        potentialSavings: 3,
        fixable: false
      });
    }
  }

  return suggestions;
}

/**
 * Intelligent whitespace & syntax auto-minifier
 */
export function autoMinifyGolfCode(code: string, language: string): string {
  if (language === 'brainfuck') {
    // Keep only the 8 valid brainfuck instructions
    return code.replace(/[^><+\-.,[\]]/g, '');
  }

  if (language === 'javascript') {
    let min = code;
    // Remove single line comments
    min = min.replace(/\/\/[^\n]*/g, '');
    // Remove multi-line comments
    min = min.replace(/\/\*[\s\S]*?\*\//g, '');
    // Collapse newlines and whitespace around operators
    min = min.replace(/\s*([=+\-*/%&|^!<>?:,;{}()[\]])\s*/g, '$1');
    // Collapse any remaining multi-spaces into single space
    min = min.replace(/\s+/g, ' ');
    // Remove trailing semicolons before closing braces
    min = min.replace(/;}/g, '}');
    // Remove trailing semicolon at the very end
    min = min.replace(/;$/, '');
    return min.trim();
  }

  if (language === 'python') {
    // For python, cannot arbitrarily remove spaces around keywords, but can clean up comments and extra blank lines
    let min = code.replace(/#[^\n]*/g, '');
    min = min.split('\n').map(l => l.trimEnd()).filter(Boolean).join('\n');
    return min.trim();
  }

  return code.trim();
}
