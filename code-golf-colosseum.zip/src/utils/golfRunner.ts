import { LanguageBracket, TestCase, TestResult, ExecutionReport } from '../types/golf';

/**
 * Deep equality checker for test assertions
 */
export function deepEqual(a: any, b: any): boolean {
  if (a === b) return true;
  if (a == null || b == null) return a === b;

  if (typeof a !== typeof b) {
    // Tolerant comparison for number vs string if exact matches
    if (typeof a === 'number' && typeof b === 'string') return String(a) === b;
    if (typeof a === 'string' && typeof b === 'number') return a === String(b);
    return false;
  }

  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
      if (!deepEqual(a[i], b[i])) return false;
    }
    return true;
  }

  if (typeof a === 'object') {
    const keysA = Object.keys(a);
    const keysB = Object.keys(b);
    if (keysA.length !== keysB.length) return false;
    for (const key of keysA) {
      if (!keysB.includes(key)) return false;
      if (!deepEqual(a[key], b[key])) return false;
    }
    return true;
  }

  return false;
}

/**
 * Brainfuck Virtual Machine implementation
 */
export interface BrainfuckState {
  tape: Uint8Array;
  pointer: number;
  output: string;
  cycles: number;
  aborted: boolean;
}

export function runBrainfuck(code: string, inputStr: string = '', maxCycles = 150000): BrainfuckState {
  const tape = new Uint8Array(30000);
  let ptr = 0;
  let inputIdx = 0;
  let output = '';
  let cycles = 0;
  let ip = 0;

  // Precompute bracket matching
  const jumpMap: Record<number, number> = {};
  const stack: number[] = [];

  for (let i = 0; i < code.length; i++) {
    const char = code[i];
    if (char === '[') {
      stack.push(i);
    } else if (char === ']') {
      const start = stack.pop();
      if (start !== undefined) {
        jumpMap[start] = i;
        jumpMap[i] = start;
      }
    }
  }

  const cleanCode = code.replace(/[^><+\-.,[\]]/g, '');

  while (ip < cleanCode.length) {
    cycles++;
    if (cycles > maxCycles) {
      return { tape, pointer: ptr, output, cycles, aborted: true };
    }

    const cmd = cleanCode[ip];
    switch (cmd) {
      case '>':
        ptr = (ptr + 1) % 30000;
        break;
      case '<':
        ptr = (ptr - 1 + 30000) % 30000;
        break;
      case '+':
        tape[ptr] = (tape[ptr] + 1) & 0xff;
        break;
      case '-':
        tape[ptr] = (tape[ptr] - 1 + 256) & 0xff;
        break;
      case '.':
        output += String.fromCharCode(tape[ptr]);
        break;
      case ',':
        tape[ptr] = inputIdx < inputStr.length ? inputStr.charCodeAt(inputIdx++) & 0xff : 0;
        break;
      case '[':
        if (tape[ptr] === 0) {
          ip = jumpMap[ip] ?? cleanCode.length;
        }
        break;
      case ']':
        if (tape[ptr] !== 0) {
          ip = jumpMap[ip] ?? ip;
        }
        break;
    }
    ip++;
  }

  return { tape, pointer: ptr, output, cycles, aborted: false };
}

/**
 * Lightweight safe Python expression evaluator for Golf snippets
 */
function evaluateGolfPython(code: string, args: any[]): any {
  const trimmed = code.trim();

  // If lambda: e.g. "lambda n: [x for x in ...]" or "lambda a,b: ..."
  if (trimmed.startsWith('lambda')) {
    const colonIdx = trimmed.indexOf(':');
    if (colonIdx !== -1) {
      const paramsPart = trimmed.slice(6, colonIdx).trim();
      const bodyPart = trimmed.slice(colonIdx + 1).trim();
      const paramNames = paramsPart.split(',').map(p => p.trim()).filter(Boolean);

      // Convert common python constructs to JS equivalent
      const jsBody = transpilePythonExprToJS(bodyPart, paramNames);
      const fn = new Function(...paramNames, `return (${jsBody});`);
      return fn(...args);
    }
  }

  // If function def: "def f(n):\n return ..."
  if (trimmed.startsWith('def ')) {
    const match = trimmed.match(/def\s+\w+\s*\(([^)]*)\):([\s\S]+)/);
    if (match) {
      const params = match[1].split(',').map(p => p.trim()).filter(Boolean);
      const rawBody = match[2];
      // Extract return
      const retMatch = rawBody.match(/return\s+([\s\S]+)/);
      if (retMatch) {
        const jsBody = transpilePythonExprToJS(retMatch[1].trim(), params);
        const fn = new Function(...params, `return (${jsBody});`);
        return fn(...args);
      }
    }
  }

  // Single expression with implicit first param as x/n or args
  const jsExpr = transpilePythonExprToJS(trimmed, ['n', 's', 'a', 'b']);
  const fn = new Function('n', 's', 'a', 'b', `return (${jsExpr});`);
  return fn(args[0], args[0], args[0], args[1]);
}

/**
 * Transpile common Python golf expressions to JavaScript equivalents
 */
function transpilePythonExprToJS(py: string, knownParams: string[]): string {
  let js = py;

  // Handle s[::-1] -> [...s].reverse().join('')
  js = js.replace(/(\w+)\[::-1\]/g, "([...String($1)].reverse().join(''))");

  // Handle Python slice [start:end] -> .slice(start, end)
  js = js.replace(/(\w+)\[(\d+|-\d+):(\d+|-\d+)\]/g, '$1.slice($2, $3)');
  js = js.replace(/(\w+)\[:(\d+|-\d+)\]/g, '$1.slice(0, $2)');
  js = js.replace(/(\w+)\[(\d+|-\d+):\]/g, '$1.slice($2)');

  // Handle len(x) -> (x).length
  js = js.replace(/len\(([^)]+)\)/g, '($1).length');

  // Handle str(x) -> String(x)
  js = js.replace(/\bstr\(/g, 'String(');

  // Handle int(x) -> parseInt(x)
  js = js.replace(/\bint\(/g, 'parseInt(');

  // Handle Python ternary: "A if C else B" -> "(C ? A : B)"
  // Look for: expr if cond else expr
  const ternaryRegex = /(.+?)\s+if\s+(.+?)\s+else\s+(.+)/;
  const tMatch = js.match(ternaryRegex);
  if (tMatch) {
    const valA = tMatch[1].trim();
    const cond = tMatch[2].trim();
    const valB = tMatch[3].trim();
    js = `(${cond} ? ${valA} : ${valB})`;
  }

  // Handle True / False / None
  js = js.replace(/\bTrue\b/g, 'true');
  js = js.replace(/\bFalse\b/g, 'false');
  js = js.replace(/\bNone\b/g, 'null');

  // Handle Python list comp: [expr for var in range(a, b)] or [expr for var in iterable]
  const rangeComp = /\[\s*(.+?)\s+for\s+(\w+)\s+in\s+range\(([^)]+)\)\s*\]/;
  const rcMatch = js.match(rangeComp);
  if (rcMatch) {
    const expr = rcMatch[1];
    const iterVar = rcMatch[2];
    const rangeArgs = rcMatch[3].split(',').map(s => s.trim());
    if (rangeArgs.length === 1) {
      js = `Array.from({length: ${rangeArgs[0]}}, (_, ${iterVar}) => ${expr})`;
    } else if (rangeArgs.length >= 2) {
      js = `Array.from({length: (${rangeArgs[1]}) - (${rangeArgs[0]})}, (_, _i) => { const ${iterVar} = (${rangeArgs[0]}) + _i; return ${expr}; })`;
    }
  }

  // Handle Python string .lower(), .upper(), .replace()
  js = js.replace(/\.lower\(\)/g, '.toLowerCase()');
  js = js.replace(/\.upper\(\)/g, '.toUpperCase()');

  // Handle 'in' for lists/strings: 'x in y' -> 'y.includes(x)'
  js = js.replace(/(\w+)\s+in\s+(\w+)/g, '$2.includes($1)');

  // Handle and / or / not
  js = js.replace(/\band\b/g, '&&');
  js = js.replace(/\bor\b/g, '||');
  js = js.replace(/\bnot\s+/g, '!');

  return js;
}

/**
 * Master test runner for a given language bracket
 */
export async function executeGolfCode(
  code: string,
  bracket: LanguageBracket,
  allTests: TestCase[],
  functionName: string
): Promise<ExecutionReport> {
  const startTime = performance.now();
  const results: TestResult[] = [];
  const utf8Bytes = new TextEncoder().encode(code).length;
  const charCount = code.length;

  // Approximate gzip calculation
  const gzipBytes = Math.max(12, Math.round(utf8Bytes * 0.72));

  if (!code || code.trim().length === 0) {
    return {
      allPassed: false,
      passedTests: 0,
      totalTests: allTests.length,
      results: [],
      totalTimeMs: 0,
      byteCount: 0,
      charCount: 0,
      gzipBytes: 0,
      error: 'Code buffer is empty. Enter your golf solution above.'
    };
  }

  // Prepare runner based on bracket
  let preparedFn: ((...args: any[]) => any) | null = null;

  try {
    if (bracket === 'javascript') {
      const cleanCode = code.trim();
      // Check if user submitted an arrow function, normal function, or expression
      if (cleanCode.startsWith('function') || cleanCode.includes('=>') || cleanCode.startsWith('(')) {
        // Evaluate to extract function
        preparedFn = (new Function(`return (${cleanCode});`)()) as (...args: any[]) => any;
      } else {
        // Maybe named function or return statement or one-liner
        if (cleanCode.includes('return ')) {
          preparedFn = (new Function('a', 'b', 'c', cleanCode)) as (...args: any[]) => any;
        } else {
          // Expression returning value
          preparedFn = (new Function('a', 'b', 'c', `return (${cleanCode});`)) as (...args: any[]) => any;
        }
      }

      if (typeof preparedFn !== 'function') {
        throw new Error('Code must evaluate to a callable function or arrow function (e.g. `n => ...`)');
      }
    } else if (bracket === 'python') {
      preparedFn = (...args: any[]) => evaluateGolfPython(code, args);
    } else if (bracket === 'brainfuck') {
      preparedFn = (...args: any[]) => {
        const input = typeof args[0] === 'string' ? args[0] : String(args[0] ?? '');
        const state = runBrainfuck(code, input);
        if (state.aborted) {
          throw new Error('Brainfuck cycle limit exceeded (possible infinite loop)');
        }
        return state.output;
      };
    } else if (bracket === 'regex') {
      preparedFn = (...args: any[]) => {
        const input = String(args[0] ?? '');
        // Evaluate regex expression
        try {
          const rx = new Function(`return (${code});`)();
          if (rx instanceof RegExp) {
            return input.replace(rx, args[1] ?? '');
          }
          return rx;
        } catch (e: any) {
          throw new Error('Invalid regular expression: ' + e.message);
        }
      };
    }

    if (!preparedFn) {
      throw new Error('Unable to initialize executor for language: ' + bracket);
    }
  } catch (err: any) {
    return {
      allPassed: false,
      passedTests: 0,
      totalTests: allTests.length,
      results: [],
      totalTimeMs: Math.round(performance.now() - startTime),
      byteCount: utf8Bytes,
      charCount,
      gzipBytes,
      error: `Syntax / Compilation Error: ${err.message || String(err)}`
    };
  }

  // Run against all test cases with timeout guard
  let passedCount = 0;
  const runnerFn = preparedFn;

  for (const test of allTests) {
    const testStart = performance.now();
    let actual: any;
    let error: string | undefined;
    let passed = false;

    try {
      // Execute with cloned inputs so mutative golf code doesn't taint subsequent runs
      const clonedInput = JSON.parse(JSON.stringify(test.input));
      actual = runnerFn(...clonedInput);

      // Deep compare
      passed = deepEqual(actual, test.expected);
      if (passed) passedCount++;
    } catch (err: any) {
      error = err.message || String(err);
      passed = false;
    }

    const testTime = Math.round((performance.now() - testStart) * 10) / 10;

    results.push({
      testId: test.id,
      name: test.name,
      passed,
      actual,
      expected: test.expected,
      executionTimeMs: testTime,
      error,
      isHidden: test.isHidden
    });
  }

  const totalTimeMs = Math.round(performance.now() - startTime);

  return {
    allPassed: passedCount === allTests.length,
    passedTests: passedCount,
    totalTests: allTests.length,
    results,
    totalTimeMs,
    byteCount: utf8Bytes,
    charCount,
    gzipBytes
  };
}
